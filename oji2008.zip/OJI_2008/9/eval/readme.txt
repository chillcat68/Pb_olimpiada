1. Se compileaza sursele elevilor folosind compilatorul Borland Pascal 7.0 pentru sursele 
   cu extensia .pas si respectiv compilatorul Borland C 3.1 pentru sursele cu extensia .c sau .cpp.
   Compilarea surselor C/CPP se vor face implicit cu modelul de memorie Large. Daca elevul solicita un alt model 
   de memorie printr-un comentariu la inceputul sursei, compilarea se va face cu modelul de memorie specificat de elev.
2. Pentru fiecare executabil obtinut:
   - se copiaza in directorul eval_p (pentru problema Pluricex), respectiv eval_c (pentru problema Concurs).
   - se lanseaza in executie comanda testall.bat numeexecutabil.exe
   - se noteaza in borderoul de evaluare rezultatele obtinute de elev pe fiecare test.




