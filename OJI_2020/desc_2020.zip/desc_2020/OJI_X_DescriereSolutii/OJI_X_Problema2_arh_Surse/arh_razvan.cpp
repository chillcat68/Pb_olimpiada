/// Sursa - recursivitate 100p
/// student Razvan Turturica
#include <fstream>
#include <cassert>

using namespace std;

ifstream cin("arh.in");
ofstream cout("arh.out");

string s;
char ans[200010];
int arhivari = 0;

int number(int &poz){
    int rsp = 0;
    while(s[poz] >= '0' && s[poz] <= '9'){
        rsp = rsp * 10 + s[poz] - '0';
        poz++;
    }
    return rsp;
}

int mksir(int &poz, int start){

    if(s[poz] == '['){
        arhivari++;
        if(s[poz + 1] == '*'){
            poz += 2;
            int stop = mksir(poz, start);
            int l = stop - start + 1;
            for(int i = 0 ; i < l ; i++){
                ans[stop + 1 + i] = ans[stop - i];
            }
            poz += 1;
            return mksir(poz, stop + l + 1);
        } else {
            poz++;
            int stop = mksir(poz, start);
            int l = stop - start + 1;
            for(int i = 1 ; i < l ; i++){
                ans[stop + i] = ans[stop - i];
            }
            poz += 2;
            return mksir(poz, stop + l);
        }
    } else {
        if(s[poz] >= '0' && s[poz] <= '9') {
            arhivari++;
            int rep = number(poz);
            poz++;
            int stop = mksir(poz, start);
            int l = stop - start + 1;
            for(int i = 1 ; i < rep ; i++){
                for(int j = start ; j <= stop ; j++){
                    ans[start + i * l + j -start] = ans[j];
                }
            }
            poz++;
            return mksir(poz, stop + (rep-1) * l + 1);
        } else if(s[poz] >= 'a' && s[poz] <= 'z') {
            int stop = start;
            while(s[poz] >= 'a' && s[poz] <= 'z'){
                ans[stop++] = s[poz];
                poz++;
            }
            return mksir(poz, stop);
        } else {
            return start - 1;
        }
    }
}

int main(){
    cin >> s;
    assert(s.size() <= 10000);
    int x = 0;
    int l = -1;
    do{
        l = mksir(x, l + 1);
    } while(x < s.size());
    assert(l <= 199999);
    cout << arhivari << '\n' << ans;
    return 0;
}
