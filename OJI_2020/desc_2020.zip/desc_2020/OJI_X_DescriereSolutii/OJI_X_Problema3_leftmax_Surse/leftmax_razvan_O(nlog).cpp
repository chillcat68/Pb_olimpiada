/// 100 p complexitate O(nlogn)
/// std. Razvan Turturica
#include <fstream>

using namespace std;

ifstream cin("leftmax.in");
ofstream cout("leftmax.out");

int v[100010], arb[400010];

long long int gauss(long long int x){
    return x * (x + 1) / 2;
}

void update(int nod, int left, int right, int poz){
    int middle = (left + right) / 2;
    if(left == right){
        arb[nod] = 1;
        return;
    }
    if(poz <= middle)
        update(2 * nod, left, middle, poz);
    else
        update(2 * nod + 1, middle + 1, right, poz);
    arb[nod] = arb[2 * nod] + arb[2 * nod + 1];
}

int getLeft(int nod, int left, int right, int poz){
    int middle = (left + right) / 2;
    if(left == right)
        return left;
    if(arb[2 * nod] < poz)
        return getLeft(2 * nod + 1, middle + 1, right, poz - arb[2 * nod]);
    else
        return getLeft(2 * nod, left, middle, poz);
}

int getRight(int nod, int left, int right, int poz){
    int middle = (left + right) / 2;
    if(left == right)
        return left;
    if(arb[2 * nod + 1] < poz)
        return getRight(2 * nod, left, middle, poz - arb[2 * nod + 1]);
    else
        return getRight(2 * nod + 1, middle + 1, right, poz);
}

int getSum(int nod, int left, int right, int L, int R){
    int middle = (left + right) / 2;
    if(L <= left && right <= R)
        return arb[nod];
    if(left > R || right < L)
        return 0;
    return getSum(2 * nod, left, middle, L, R) +
           getSum(2 * nod + 1, middle + 1, right, L, R);
}

int main(){
    int n;
    cin >> n;
    for(int i = 1 ; i <= n ; i++){
        int x;
        cin >> x;
        v[x] = i;
    }
    long long int ans = 0;
    int l, r, x;
    for(int i = n ; i >= 1 ; i--){
        x = getSum(1, 1, n, 1, v[i]);
        if(x != 0)
            l = v[i] - getLeft(1, 1, n, x) - 1;
        else
            l = v[i] - 1;
        x = getSum(1, 1, n, v[i], n);
        if(x != 0)
            r = getRight(1, 1, n, x) - v[i] - 1;
        else
            r = n - v[i];
        l = max(l, 0);
        r = max(r, 0);
        update(1, 1, n, v[i]);
        if(r <= l)
            ans += gauss(r + 1);
        else
            ans += gauss(r + 1) - gauss(r - l);
    }
    cout << ans % 1000000007;
    return 0;
}
