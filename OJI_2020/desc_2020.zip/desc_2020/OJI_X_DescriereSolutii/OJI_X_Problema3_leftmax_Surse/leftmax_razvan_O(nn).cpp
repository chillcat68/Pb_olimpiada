/// 45 p complexitate O(nxn)
/// std. Razvan Turturica
#include <fstream>

using namespace std;

ifstream cin("leftmax.in");
ofstream cout("leftmax.out");

int v[100010];

int main(){
    int n;
    cin >> n;
    for(int i = 1 ; i <= n ; i++){
        cin >> v[i];
    }
    long long int ans = 0;
    for(int i = 1 ; i <= n ; i++){
        int maxi = 0;
        for(int j = i ; j <= n ; j++){
            if(v[j] > v[maxi])
                maxi = j;
            if(maxi <= (i + j) / 2)
                ans++;
        }
    }
    cout << ans % 1000000007;
    return 0;
}
