///brut - 15p
#include <bits/stdc++.h>
using namespace std;

using ll = long long;
using cd = complex<double>;

int main(){
    ifstream f("leftmax.in");
    ofstream g("leftmax.out");
    int n;
    
    f >> n;

    vector<int> v(n);
    for(auto& x : v)
        f >> x;

    ll ret = 0;

    for(int i = 0; i < n; ++i){
        int k = i;
        for(int j = i; j < n; ++j){
            int k = i;
            for(int l = i; l <= j; ++l)
                if(v[l] > v[k]) k = l;
            if(2 * (k - i) <= j - i)
                ++ret;
        }
    }

    g << ret % (1000 * 1000 * 1000 + 7) << endl;

    return 0;
}

