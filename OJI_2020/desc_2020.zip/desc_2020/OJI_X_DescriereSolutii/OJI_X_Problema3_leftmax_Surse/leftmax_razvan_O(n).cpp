///100 p complexitate O(n)
/// std. Razvan Turturica
#include <fstream>
#include <stack>
#include <cassert>

using namespace std;

ifstream cin("leftmax.in");
ofstream cout("leftmax.out");

stack<int> st;
int v[100010], l[100010], r[100010], fv[100010];

long long int gauss(long long int x){
    return x * (x + 1) / 2;
}

int main(){
    int n;
    cin >> n;
    assert(n >= 1);
    assert(n <= 100000);
    for(int i = 1 ; i <= n ; i++){
        cin >> v[i];
        assert(v[i] <= n);
        assert(v[i] >= 1);
        fv[v[i]]++;
    }
    for(int i = 1 ; i <= n ; i++){
        assert(fv[i] == 1);
    }
    v[0] = v[n + 1] = n + 1;
    st.push(0);
    for(int i = 1 ; i <= n ; i++){
        while(v[st.top()] < v[i])
            st.pop();
        l[i] = i - st.top() - 1;
        st.push(i);
    }
    while(st.size())
        st.pop();
    st.push(n+1);
    for(int i = n ; i >= 1 ; i--){
        while(v[st.top()] < v[i])
            st.pop();
        r[i] = st.top() - i - 1;
        st.push(i);
    }
    long long int ans = 0;
    for(int i = 1 ; i <= n ; i++){
        if(r[i] <= l[i])
            ans += gauss(r[i] + 1);
        else
            ans += gauss(r[i] + 1) - gauss(r[i]-l[i]);
    }
    cout << ans % 1000000007;
    return 0;
}

