/// sursa 100 p 
/// std. Bogdan Sitaru
#include <bits/stdc++.h>

using namespace std;

typedef long long LL;

const int NMAX = 185;
const int mod = 180;

int N, P, Z;
int f[NMAX], now[NMAX];

int main() {
	freopen("alinieri.in", "r", stdin);
	freopen("alinieri.out", "w", stdout);

	assert( scanf("%d%d%d", &N, &P, &Z) == 3 );
	assert(2 <= P && P <= 1e5);
	assert(2 <= N && N <= 1e5);
	assert(1 <= Z && Z <= 1e6);
	for(int i = 0; i < N; i++) {
		int x;
		assert( scanf("%d", &x) == 1 );
		assert(1 <= x && x <= 1e3);
		f[x % mod]++;
	}

	LL tot = 0, ans = 0;
	int r = Z % mod;
	for(int i = 0; i < 180; i++) {
		for(int j = 0; j < 180; j++)	now[j] = 0;
		for(int j = 0; j < 180; j++)
			now[(j * (i + 1)) % mod] += f[j];

		int cnt = 0;
		for(int j = 0; j < 180; j++)
			cnt += now[j] >= P;
		tot += cnt;
		if(i < r)	ans += cnt;
	}
	ans += tot * (Z / 180);

	printf("%lld\n", ans);

	return 0;
}
