// prof. Chesca Ciprian - sursa C++
// Complexitate O(365*N)

#include <fstream>
#define nmax 1000001
#define smax 400

using namespace std;

ifstream f("alinieri.in");
ofstream g("alinieri.out");

int N,P,Z,v[nmax],w[smax];


int main()
{
int t,i,na,nta;

f>>N>>P>>Z;
for(i=1;i<=N;i++)
    f>>v[i];

nta=0;
for(t=1;t<=360;t++)
{
    na=0;
    for(i=0;i<=179;i++)
        w[i]=0;

    for(i=1;i<=N;i++)
        w[(t*v[i])%180]++;

       
    for(i=0;i<=179;i++)
        if (w[i]>=P) na++;

    nta+=na;

}

nta*=(Z/360);

for(t=1;t<=Z%360;t++)
{
    na=0;
    for(i=0;i<=179;i++)
        w[i]=0;

    for(i=1;i<=N;i++)
        w[(t*v[i])%180]++;

       
    for(i=0;i<=179;i++)
        if (w[i]>=P) na++;

    nta+=na;

}

g<<nta<<"\n";

f.close();
g.close();
return 0;
}



