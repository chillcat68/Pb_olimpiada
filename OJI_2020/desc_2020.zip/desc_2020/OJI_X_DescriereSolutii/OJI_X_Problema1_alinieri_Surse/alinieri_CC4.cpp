// prof. Chesca Ciprian - sursa C++ - 100 p
// Complexitate O(N)


#include <bits/stdc++.h>
#define nmax 181


using namespace std;

ifstream f("alinieri.in");
ofstream g("alinieri.out");

int N,P,Z,gp[nmax],w[nmax],na,nta,nta1=0,nta2=0;



int main()
{
int t,i,x;

f>>N>>P>>Z;


for(i=1;i<=N;i++)
{
    f>>x;
    assert(x>=1 && x <=1000);
    gp[x%180]++;
}

assert(N>=1 && N<=100000);
assert(P>=2 && P<=N);
assert(Z>=1 && Z<=1000000);



for(t=1;t<=180;t++)
{
    na=0;
    for(i=0;i<=179;i++)
        w[i]=0;

    for(i=0;i<=179;i++)
        w[(t*i)%180]+=gp[i];


    for(i=0;i<=179;i++)
        if (w[i]>=P) na++;
    
    nta+=na;

}

nta*=2*(Z/360);

for(t=1;t<=Z%360;t++)
{
    na=0;
    for(i=0;i<=179;i++)
        w[i]=0;

    for(i=0;i<=179;i++)
        w[(t*i)%180]+=gp[i];


    for(i=0;i<=179;i++)
        if (w[i]>=P) na++;
    
    nta+=na;

}


g << nta << "\n";

f.close();
g.close();
return 0;
}



