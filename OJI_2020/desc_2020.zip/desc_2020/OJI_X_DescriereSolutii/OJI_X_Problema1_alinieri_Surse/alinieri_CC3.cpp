// prof. Chesca Ciprian
// Complexitate O(Z)


#include <fstream>
#define nmax 181

using namespace std;

ifstream f("alinieri.in");
ofstream g("alinieri.out");

int N,P,Z,gp[nmax],w[nmax],na,nta=0;


int main()
{
int t,i,x;

f>>N>>P>>Z;
for(i=1;i<=N;i++)
{
    f>>x;
    gp[x%180]++;
}



for(t=1;t<=Z;t++)
{
    na=0;
    for(i=0;i<=179;i++)
        w[i]=0;

    for(i=0;i<=179;i++)
        if (gp[i])  w[(t*i)%180]+=gp[i];


    for(i=0;i<=179;i++)
        if (w[i]>=P) na++;
    
    nta+=na;

}


g << nta << "\n";

f.close();
g.close();
return 0;
}



