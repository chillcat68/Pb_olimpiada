//Em. Cerchez 100 puncte
#include <fstream>
#define NMAX 1002

using namespace std;
ifstream fin("triunghi.in");
ofstream fout("triunghi.out");
int n, Q;
int A[NMAX][NMAX];
int sl[NMAX][NMAX];//sl[i][j]=suma elementele de pe linia i de la 1 la j
int sd[NMAX][NMAX];//sd[i][j]=suma elem din dreptunghiul cu colutl 1,1 si coltul i,j
int st[NMAX][NMAX];//st[i][j] este suma elementelor din trapezul cu baza mare pe linia 1
//si baza mica pe linia i de la 1 la j
int smax;
int detsuma(int lin, int col, int k);
int main()
{int i, j, lin, col, k, t, suma;
 fin>>n;
 for (i=1; i<=n; i++)
     for (j=1; j<=n; j++)
         {
          fin>>A[i][j];
          sl[i][j]=sl[i][j-1]+A[i][j];
          sd[i][j]=sd[i-1][j]+sd[i][j-1]-sd[i-1][j-1]+A[i][j];
          if (j==n) st[i][j]=sd[i][j]; else st[i][j]=st[i-1][j+1]+sl[i][j];
          }

 fin>>Q;
 for (t=0; t<Q; t++)
     {
      fin>>lin>>col>>k;
      if (k>0)
          suma=detsuma(lin,col,k);
          else
          suma=sd[lin][col]-sd[lin][col+k]-sd[lin+k][col]+sd[lin+k][col+k]-detsuma(lin+k+1,col+k+1,-k-1);
      if (suma>smax) smax=suma;
     }
 fout<<smax<<'\n';
 fout.close();
 return 0;
}


int detsuma(int lin, int col, int k)
{
 if (col+k-1==n)
    return st[lin+k-1][col]-sd[lin+k-1][col-1]-sd[lin-1][col+k-1]+sd[lin-1][col-1];
 return    st[lin+k-1][col]-sd[lin+k-1][col-1]-st[lin-1][col+k]  +sd[lin-1][col-1];
}

