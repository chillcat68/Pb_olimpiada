///Alin Burta 100 puncte
#include <fstream>
#include <cstring>
#include <cstdlib>
#include <cctype>
#define MaxF 3001

using namespace std;

ifstream citeste("datorii.in");
ofstream   scrie("datorii.out");

struct firma
{
    char nume[21];
    long long SP, SD;
};

int C, D;
firma v[62][MaxF];
int nrFirme = 0;
int nrF[62] = {0};

int apartine(char*);

int main()
{
    char linie[500], numeFirma1[21], numeFirma2[21];
    int i, j;
    int suma;
    int poz;
    firma tmp;
    int lista;
    //citesc datele de intrare
    citeste >> C >> D;
    citeste.get();

    for(i = 1; i <= D; ++i)
    {
        citeste.get(linie,500);
        citeste.get();
        //extrageDate(linie, numeFirma1, numeFirma2, suma);

        //extrag datele
        char *cuv,ii;
        int z = 1;
        ii = strlen(linie) - 1;
        suma = 0;
        while ( 48 <= linie[ii] && linie[ii] <= 57)
        {
            suma = suma + z * (linie[ii]-48);
            z *= 10;
            ii--;
        }
        ii++;
        linie[ii-1] = '\0';
        cuv = strchr(linie, '>');
        strncpy(numeFirma1, linie, cuv - linie - 1);
        numeFirma1[cuv - linie - 1] ='\0';
        strcpy(numeFirma2, cuv+2);

        //pun firmele la locul lor
        poz = apartine(numeFirma1);
        if(isdigit(numeFirma1[0]))
            lista = numeFirma1[0] - '0';
        else
            if(isupper(numeFirma1[0]))
                lista = 10 + numeFirma1[0] - 'A';
            else
                lista = 36 + numeFirma1[0] - 'a';
        if(poz)
            v[lista][poz].SD += suma;
        else
        {
            nrFirme++;
            nrF[lista]++;
            strcpy(v[lista][nrF[lista]].nume,numeFirma1);
            v[lista][nrF[lista]].SP = 0;
            v[lista][nrF[lista]].SD = suma;
            //mut firma la locul ei
            for(j = nrF[lista]; j>1 && strcmp(v[lista][j].nume, v[lista][j-1].nume) < 0; j--)
                tmp = v[lista][j], v[lista][j] = v[lista][j-1], v[lista][j-1] = tmp;
        }
        poz = apartine(numeFirma2);
        if(isdigit(numeFirma2[0]))
            lista = numeFirma2[0] - '0';
        else
            if(isupper(numeFirma2[0]))
                lista = 10 + numeFirma2[0] - 'A';
            else
                lista = 36 + numeFirma2[0] - 'a';
        if(poz)
            v[lista][poz].SP += suma;
        else
        {
            nrFirme++;
            nrF[lista]++;
            strcpy(v[lista][nrF[lista]].nume,numeFirma2);
            v[lista][nrF[lista]].SP = suma;
            v[lista][nrF[lista]].SD = 0;
            //mut firma la locul ei
            for(j = nrF[lista]; j>1 && strcmp(v[lista][j].nume, v[lista][j-1].nume) < 0; j--)
                tmp = v[lista][j], v[lista][j] = v[lista][j-1], v[lista][j-1] = tmp;
        }
    }

    if( C == 1)
    {
        scrie << nrFirme <<'\n';
    }
    else
    {
        for(i = 0; i < 62; ++i)
            if(nrF[i])
                for(j = 1; j <= nrF[i]; ++j)
                    scrie << v[i][j].nume << " " << v[i][j].SD << " " << v[i][j].SP << '\n';
    }

    citeste.close();
    scrie.close();
    return 0;
}


int apartine(char *denumire)
{
    int st, dr, mij;
    int lista;
    if(isdigit(denumire[0]))
        lista = denumire[0] - '0';
    else
        if(isupper(denumire[0]))
            lista = 10 + denumire[0] - 'A';
        else
            lista = 36 + denumire[0] - 'a';
    st = 1; dr = nrF[lista];
    while(st <= dr)
    {
        mij = (st + dr)/2;
        if(strcmp(v[lista][mij].nume, denumire) == 0)
            return mij;
        else
            if(strcmp(v[lista][mij].nume, denumire) < 0)
                st = mij + 1;
            else
                dr = mij - 1;
    }
    return 0;
}
