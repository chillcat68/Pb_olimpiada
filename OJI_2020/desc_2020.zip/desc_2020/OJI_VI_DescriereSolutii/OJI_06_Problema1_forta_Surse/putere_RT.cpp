//Roxana Timplaru
#include <iostream>
#include <algorithm>
#include<fstream>
using namespace std;

ifstream fin("forta.in");
ofstream fout("forta.out");


int p[45001],k,x[100001],y[100001],n;

void ciur()
{
    int i,j;
    for(i=3;i<=212;i=i+2)
        if (p[i]==0)
        for(j=i*i;j<=45000;j=j+i)
         p[j]=1;
    x[1]=2;k=1;
    for(i=3;i<=45000;i=i+2)
            if (p[i]==0)
                {
                k++;
                x[k]=i;
                }
}


int numara_div(int a)
{
    int t,nr=1,i=1;
   if (a==2)
        return 2;
    while ( x[i]*x[i]<=a)
        {  t=0;
            while (a%x[i]==0)
            {
            a=a/x[i];
            t++;
            }
            if (t)
            nr=nr*(t+1);
            i++;
    }
    if (a!=1) nr=nr*2; // e nr prim
     return nr;
}

void cerinta_2()
{
    int x,i,a,maxi=0,k,ok,q;
    //fin>>n;
    for(i=1;i<=n;i++)
    {
        fin>>x;
        y[i]=numara_div(x);
    }
    sort(y,y+n+1);
   /* do
    {
        ok=0;
        for(i=1;i<n;i++)
            if (y[i]>y[i+1])
        {
            q=y[i];
            y[i]=y[i+1];
            y[i+1]=q;
            ok=1;
        }
    } while (ok);*/
    k=1;
    a=y[1];
    for(i=2;i<=n;i++)
        if (y[i]==a)
        k++;
        else
        {
            if (maxi<k)
                maxi=k;
            a=y[i];
            k=1;}

     if(maxi<k)
            maxi=k;
    fout<<maxi;


}

int main()
{
    int i,a,cerinta,maxi=0,nr,t;
    ciur();
    fin>>cerinta>>n;
    if (cerinta==1)
    {
        for (i=1;i<=n;i++)
        {
            fin>>a;
            t=numara_div(a);
            if (t>maxi)
            {
                maxi=t;
                nr=a;
            }
            else
                if (t==maxi)
                 if (nr>a)
                 nr=a;
        }
        fout<<nr;
    }
    else
         if (cerinta==2)
               cerinta_2();

    return 0;

}
