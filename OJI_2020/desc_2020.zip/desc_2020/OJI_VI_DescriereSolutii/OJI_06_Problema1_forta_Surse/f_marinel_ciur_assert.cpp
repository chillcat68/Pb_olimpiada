//marinel februarie 2020
#include <fstream>
#include <cstring>
#include <cassert>

using namespace std;

ifstream fin("forta.in");
ofstream fout("forta.out");

#define dim 100001

struct elem
{
   int X;
   short int nrdiv;
} divi[dim];

int X, x, cx, d, cerinta, n, nrd_citit, i, imax, mic, m;
int Pmax, nr_max, p, u, cate, cate_max, pmax, umax, Fmax;
int F[dim], P[45001];
char C[45001];

int nrD(int n)
{
    int k = 1, p, d = 1;         //folosesc formula d = (p1+1)(p2+1)...(pk+1)
    while (P[k] * P[k] <= n)     //unde p1 p2...pk sunt puterile factorilor primi    
    {                            //din descompunere 
        p = 0;                      //initializez puterea
        while (n % P[k] == 0)       //cat timp se divide cu numarul prim P[k]
        {
            n /= P[k];              //imparte
            p++;                    //numara
        }
        d = d * (p + 1);            //formula
        k++;                        //trec la alt numar prim
    }
    if(n > 1)                    //daca a mai ramas ceva din n => este numar prim 
        d = d * 2;               //deci d se inmulteste cu (1+1) = 2
    return d;                    //returnez numarul de divizori 
}

void ciur()
{
    int i, j;                    //pentru determinarea numarului de divizori 
    C[0] = C[1] = 1;             //voi folosi DOAR numere prime impare   
    for (i = 2; i < 45001; i ++)     //suficient 45001 deoarece
        if (C[i] == 0)               //45000 * 45000 = 2025000000 > 2000000000
        {                          //am un numar prim
            m++;                   //il numar si
            P[m] = i;              //il salvez apoi elimin multipli
            for (j = i * i; j < 45001; j += i)
                C[j] = 1;
        }
}

int main()
{
    fin >> cerinta;                 //citire cerinta si
    assert(cerinta == 1 || cerinta == 2);
    fin >> n;                       //numarul de numere
    assert(n >= 1 && n <= 100000);
    ciur();                         //construiesc sirul numerelor prime
    for (i = 1; i <= n; i++)        //iau pe rand cele n numere 
    {
        fin >> X;                        //citesc numarul
        assert(X >= 1 && X <= 2000000000);
        divi[i].nrdiv = nrD(X);          //calculez si retin numarul de divizori
        divi[i].X = X;                   //retin si numarul
        F[divi[i].nrdiv]++;              //contorizez numarul de aparitii a numaruui de divizori 
        if (F[divi[i].nrdiv] > Fmax)     //determin numarul maxim de aparitii
            Fmax = F[divi[i].nrdiv];
        if (divi[i].nrdiv > Pmax)        //determin si numarul maxim de divizori
        {
            Pmax = divi[i].nrdiv;        //retin
            nr_max = X;                  //retin si pentru cine este acesta
        }
        else
            if (divi[i].nrdiv == Pmax)   //in caz de egalitate
            {
                if (X < nr_max)          //caut numarul mai mic
                    nr_max = X;
            }
    }
    if (cerinta == 1)
        fout << nr_max << '\n';      //afisez cerinta 1
    else
        fout << Fmax << '\n';        //afisez cerinta 2
    return 0;
}
