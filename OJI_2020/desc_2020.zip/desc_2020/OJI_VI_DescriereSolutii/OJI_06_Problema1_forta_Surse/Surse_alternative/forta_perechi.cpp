//Raluca Costineanu
#include <bits/stdc++.h>

using namespace std;

ifstream f("forta.in");
ofstream g("forta.out");

int nrDiv(int x)
{
    int k=0, d;
    for(d=1; d*d<x; d++)
        if(x%d==0)
        k+=2;
    if(x==d*d)k++;
    return k;
}

int main()
{
    int C;
    f>>C;
    if(C==1)
    {
        int n, i, x, k, pMax=0, nrMin=0;
        f>>n;
        for(i=1; i<=n; i++)
        {
            f>>x;
            k=nrDiv(x);
            if(k>pMax)pMax=k, nrMin=x;
            else if(k==pMax && x<nrMin)nrMin=x;
        }
        g<<nrMin<<'\n';
    }
    else
    {
        int nrD[1500]= {}, n, i, x, mx=0, k, maxim=0;
        f>>n;
        for(i=1; i<=n; i++)
        {
            f>>x;
            k=nrDiv(x);
            if(k>mx)mx=k;
            nrD[k]++;
        }
        for(i=1; i<=mx; i++)
            if(nrD[i]>maxim)maxim=nrD[i];
        g<<maxim<<'\n';
    }
    return 0;
}


