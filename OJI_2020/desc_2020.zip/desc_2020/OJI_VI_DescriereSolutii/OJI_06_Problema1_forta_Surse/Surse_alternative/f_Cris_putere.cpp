//Cristina Iordaiche
#include<fstream>
#include<cmath>
using namespace std;
ifstream fin("forta.in");
ofstream fout("forta.out");

int cerinta,prim[5000],k,n,nr[100005],grad[100005],frecv[100005],gfrecv[100005];
bool compus[46000];

void prime()
{
    for(int i=2;i<=22363;i++)
        compus[i*2]=1;
    for(int i=3;i<=213;i+=2)
        for(int j=i, aux=44725/i;j<=aux;j+=2)
            compus[i*j]=1;

    for(int i=2;i<=44725;i++)
        if(!compus[i])
        {
            prim[k++]=i;
            //fout<<i<<'\n';
        }
}

void calc_grad(int ind)
{
    int x=nr[ind];
    grad[ind]=1;
    for(int i=0;x!=1&&prim[i]<=sqrt(x)+1&&i<k;i++)
    {
        //fout<<i<<endl;
        int aux=1;
        while(x%prim[i]==0)
        {
            aux++;
            x/=prim[i];
        }
        grad[ind]*=aux;
    }
    if(x!=1)
        grad[ind]*=2;
}

void citire()
{
    fin>>cerinta>>n;
    for(int i=0;i<n;i++)
    {
        fin>>nr[i];
        calc_grad(i);
        //fout<<nr[i]<<' '<<grad[i]<<endl;
    }
}

void cerinta1()
{
    int gmax=-1,x;
    for(int i=0;i<n;i++)
    {
        if(grad[i]>gmax)
        {
            gmax=grad[i];
            x=nr[i];
        }
    }
    fout<<x<<'\n';
}

void cerinta2()
{
    int m=0,sol=-1;
    for(int i=0;i<n;i++)
    {
        bool ok=0;
        for(int j=0;j<m;j++)
        {
            if(grad[i]==gfrecv[j])
            {
                ok=1;
                frecv[j]++;
                break;
            }
        }
        if(!ok)
        {
            frecv[m]=1;
            gfrecv[m++]=grad[i];
        }
    }
    for(int i=0;i<m;i++)
    {
        sol=max(sol,frecv[i]);
    }
    fout<<sol<<'\n';
}

int main()
{
    prime();
    citire();

    if(cerinta==1)
        cerinta1();
    else if(cerinta==2)
        cerinta2();
    fin.close();
    fout.close();
    return 0;
}
