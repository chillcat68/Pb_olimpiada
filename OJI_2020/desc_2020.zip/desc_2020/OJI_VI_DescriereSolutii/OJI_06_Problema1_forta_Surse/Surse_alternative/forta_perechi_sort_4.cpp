//Raluca Costineanu
#include <bits/stdc++.h>

using namespace std;
#define nMax 100010
ifstream f("forta.in");
ofstream g("forta.out");

int nrDiv(int x)
{
    int k=0, d;
    for(d=1; d*d<x; d++)
        if(x%d==0)
            k+=2;
    if(x==d*d)k++;
    return k;
}

int a[nMax], n;
int main()
{
    int C, pMax=0, nrMin=0, x;
    f>>C>>n;
    for(int i=1; i<=n; i++)
    {
        f>>x;
        a[i]=nrDiv(x);
        if(a[i]>pMax)pMax=a[i], nrMin=x;
        else if(a[i]==pMax && x<nrMin)nrMin=x;
    }
    if(C==1)
        g<<nrMin<<'\n';
    else
    {
        sort(a+1, a+n+1);
        int lg=1, maxim=0;
        for(int i=2; i<=n; i++)
            if(a[i]==a[i-1])lg++;
            else
            {
                if(lg>maxim)maxim=lg;
                lg=1;
            }
        if(lg>maxim)maxim=lg;
        g<<maxim<<'\n';
    }
    return 0;
}


