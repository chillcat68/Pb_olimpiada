//Alina Pintescu
#include <iostream>
#include <fstream>
using namespace std;
ifstream f("forta.in");
ofstream g("forta.out");
int c,n,i,x,mx,x1,lgmax,st,dr,k,kante,lg,st1,dr1,k1;
int v[100],max3;
int putere(int x)
{
    int k=2,d;
    d=2;
    while(d*d<x)
    {
        if(x%d==0)
            k+=2;
        d++;
    }
    if(d*d==x)
        k++;
    return k;
}
int main()
{
    f>>c>>n;
    kante=0;
    lg=0;
    for(i=1; i<=n; i++)
    {
        f>>x;
        if(putere(x)>mx)
        {
            mx=putere(x);
            x1=x;
        }
        k=putere(x);
        if(k==kante)
        {
            lg++;
            dr=i;
            if(lg>lgmax)
            {
                lgmax=lg;
                st1=st;
                dr1=dr;
                k1=k;
            }
        }
        else
        {
            st=i;
            lg=1;
            kante=k;
        }
    //c
    v[k]++;
    if(v[k]>max3)
        max3=v[k];
    }
    if(c==1)
        g<<x1;
    if(c==2)
        g<<max3;
    return 0;
}
