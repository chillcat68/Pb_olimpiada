//marinel februarie 2020
#include <stdio.h>

FILE *fin, *fout;

#define dim 100001

//fac struct cu X si nrd(X), apoi...
struct elem
{
   int X;
   int nrdiv;
} divi[dim];

int X, x, cx, d, cerinta, n, nrd_citit, i, imax, mic;
int Pmax, nr_max, p, u, cate, cate_max, pmax, umax, Fmax;
int F[dim];

int nrD(int x)
{
    int cati = 0;
	if (x == 1) return 1;
	if (x == 2 || x == 3) return 2;
        cx = x;
        cati = 1;
        d = 2;
        p = 0;
        while (cx % 2 == 0)
        {
            p++;
            cx /= 2;
        }
        cati *= (p + 1);
        d = 3;
        while (cx > 1)
        {
            p = 0;
            while (cx % d == 0)
            {
                p++;
                cx /= d;
            }
            cati *= (p + 1);
            if (cx == 1) break;
            d += 2;
            if (d * d > cx)
            {
                cati *= 2;
                break;
            }
        }
    return cati;
}

int main()
{
	fin = fopen("forta.in", "r");
    fout = fopen("forta.out", "w");

    fscanf(fin, "%d", &cerinta);
    fscanf(fin, "%d", &n);
    for (i = 1; i <= n; i++)
    {
        fscanf(fin, "%d", &X);
        divi[i].nrdiv = nrD(X);
        divi[i].X = X;
        F[divi[i].nrdiv]++;
        if (F[divi[i].nrdiv] > Fmax)
            Fmax = F[divi[i].nrdiv];
        if (divi[i].nrdiv > Pmax)
        {
            Pmax = divi[i].nrdiv;
            nr_max = X;
        }
        else
            if (divi[i].nrdiv == Pmax)
            {
                if (X < nr_max)
                    nr_max = X;
            }
    }
    if (cerinta == 1)
        fprintf(fout, "%d\n", nr_max);
    else
        {
            fprintf(fout, "%d\n", Fmax);
        }
    return 0;
}
