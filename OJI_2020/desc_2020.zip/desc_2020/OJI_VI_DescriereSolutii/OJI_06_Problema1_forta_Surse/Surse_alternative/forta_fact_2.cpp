//Raluca Costineanu
#include <bits/stdc++.h>

using namespace std;

ifstream f("forta.in");
ofstream g("forta.out");

int nrDiv(int x)
{
    int k=1,p=0,d=3;
    while(x%2==0)x/=2, p++;
    k*=p+1, p=0, d=3;
    while(d*d<=x)
    {
        while(x%d==0) x/=d, p++;
        k*=p+1, d+=2, p=0;
    }
    if(x>1) k*=2;
    return k;
}

int main()
{
    int C;
    f>>C;
    if(C==1)
    {
        int n, i, x, k, pMax=0, nrMin=0;
        f>>n;
        for(i=1; i<=n; i++)
        {
            f>>x;
            k=nrDiv(x);
            if(k>pMax)pMax=k, nrMin=x;
            else if(k==pMax && x<nrMin)nrMin=x;
        }
        g<<nrMin<<'\n';
    }
    else
    {
        int nrD[1500]= {}, n, i, x, mx=0, k, maxim=0;
        f>>n;
        for(i=1; i<=n; i++)
        {
            f>>x;
            k=nrDiv(x);
            if(k>mx)mx=k;
            nrD[k]++;
        }
        for(i=2; i<=mx; i++)
            if(nrD[i]>maxim)maxim=nrD[i];
        g<<maxim<<'\n';
    }
    return 0;
}
