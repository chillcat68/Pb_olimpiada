//marinel februarie 2020
#include <fstream>
#include <cstring>

using namespace std;

ifstream fin("forta.in");
ofstream fout("forta.out");

#define dim 2000000

unsigned char divi[dim];
int X, x, cx, d, cerinta, n, nrd_citit, i, imax;
int Pmax, nr_max, p, u, cate, cate_max, pmax, umax, Fmax;
int F[130];

unsigned char nrD(int x)
{
   unsigned char cati = 0;
        cx = x;
        cati = 1;
        d = 2;
        p = 0;
        while (cx % 2 == 0)
        {
            p++;
            cx /= 2;
        }
        cati *= (p + 1);
        d = 3;
        while (cx > 1)
        {
            p = 0;
            while (cx % d == 0)
            {
                p++;
                cx /= d;
            }
            cati *= (p + 1);
            if (cx == 1) break;
            d += 2;
            if (d * d > cx)
            {
                cati *= 2;
                break;
            }
        }
    return cati;
}

int main()
{
    fin >> cerinta;
    fin >> n;
    for (i = 1; i <= n; i++)
    {
        fin >> X;
        divi[i] = nrD(X);
        F[divi[i]]++;
        if (F[divi[i]] > Fmax)
            Fmax = F[divi[i]];
        if (divi[i] > Pmax)
        {
            Pmax = divi[i];
            nr_max = X;
        }
        else
            if (divi[i] == Pmax)
            {
                if (X < nr_max)
                    nr_max = X;
            }
    }
    if (cerinta == 1)
        fout << nr_max << '\n';
    else
        {
            fout << Fmax << '\n';
        }
    return 0;
}
