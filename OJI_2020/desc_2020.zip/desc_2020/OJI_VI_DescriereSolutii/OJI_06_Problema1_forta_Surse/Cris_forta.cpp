//Cristina Iordaiche
#include <fstream>
#include <climits>


using namespace std;

ifstream fin("forta.in");
ofstream fout("forta.out");

int n,maxx=200004,viz[200004],prime[200004],k;
pair<int,int> v[100004];

void ciur()
{

    for(int i=2;i<=maxx;i++)
        if(viz[i]==0)
    {
        prime[++k]=i;
        for(int j=i;j<=maxx;j+=i)
            viz[j]=1;
    }
}

int main()
{
    ciur();
    int cerinta;
    fin>>cerinta>>n;
    for(int i=1;i<=n;i++)
    {
        int x;
        fin>>x;
        v[i].first=x;
        int putere=1;
        for(int j=1;j<=k && prime[j]*prime[j]<=x;j++)
        {
            int d=0;
            while(x%prime[j]==0)
            {
                d++;
                x/=prime[j];
            }
            if(d>0)
                putere*=d+1;

        }
        if(x>1)
            putere*=2;
        v[i].second=putere;

    }
    if(cerinta==1)
      {

          int putmax=0;
          int min1=INT_MAX;
          for(int i=1;i<=n;i++)
          {
              if(v[i].second>putmax)
              {
                  putmax=v[i].second;
                  min1=v[i].first;
              }
              if(v[i].second==putmax && min1>v[i].first)
                min1=v[i].first;

          }
          fout<<min1;

      }
      else
      {
          int sol=0,aparente[100000];
          for(int i=1;i<=n;i++)
          {
              aparente[v[i].second]++;
              if(aparente[v[i].second]>sol)
                sol=aparente[v[i].second];
          }
          fout<<sol;
      }
fout<<'\n';
return 0;
}
