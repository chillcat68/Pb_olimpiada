//Raluca Costineanu
#include <bits/stdc++.h>

using namespace std;
#define nMax 100010
ifstream f("forta.in");
ofstream g("forta.out");

bool ciur[45000];
int prime[5000], cate;
void Eratostene()
{
    for(int i=3; i<=212; i+=2)
        if(ciur[i]==0)
            for(int j=i*i; j<45000; j+=i)
            ciur[j]=1;
    cate=1;
    prime[1]=2;
    for(int i=3; i<45000; i+=2)
        if(!ciur[i])prime[++cate]=i;
}
int nrDiv(int x)
{
    int k=1,p=0,i=1;
    while(i<=cate && prime[i]*prime[i]<=x)
    {
        while(x%prime[i]==0) x/=prime[i], p++;
        k*=p+1, i++, p=0;
    }
    if(x>1) k*=2;
    return k;
}
int a[nMax], n;
int main()
{
    Eratostene();
    int C, pMax=0, nrMin=0, x;
    f>>C>>n;
    for(int i=1; i<=n; i++)
    {
        f>>x;
        a[i]=nrDiv(x);
        if(a[i]>pMax)pMax=a[i], nrMin=x;
        else if(a[i]==pMax && x<nrMin)nrMin=x;
    }
    if(C==1)
        g<<nrMin<<'\n';
    else
    {
        sort(a+1, a+n+1);
        int lg=1, maxim=0;
        for(int i=2; i<=n; i++)
            if(a[i]==a[i-1])lg++;
            else
            {
                if(lg>maxim)maxim=lg;
                lg=1;
            }
        if(lg>maxim)maxim=lg;
        g<<maxim<<'\n';
    }
    return 0;
}



