//Raluca Costineanu
#include <bits/stdc++.h>

using namespace std;
ifstream f("furnica.in");
ofstream g("furnica.out");

int c, n, unde;
long long timp, nuCoboara, mx, T, l, L, ll, LL;
int main()
{
    int i;
    f>>c;
    if(c<3)
    {
        f>>n>>l>>L;
        timp=L*5+l*3;
        mx=nuCoboara=l+L;
        for(i=2; i<=n; i++)
        {
            f>>ll>>LL;
            long long dif=LL-L;
            if(dif>=0)
                timp+=dif*5+ll*3, nuCoboara+=dif+ll, mx=max(mx, nuCoboara);
            else timp+=-dif*2+ll*3, nuCoboara=ll;
            l=ll;
            L=LL;
        }
        timp+=L*2;
        if(c==1)g<<timp<<'\n';
        else g<<mx<<'\n';
    }
    else
    {
        f>>n>>T>>l>>L;
        timp=L*5+l*3; unde=1;
        if(timp<T)
        for(i=2; i<=n; i++)
        {
            f>>ll>>LL;
            long long dif=LL-L;
            if(dif>=0)
                timp+=dif*5;
            else {  timp+=-dif*2;
                    if(timp>=T)
                    {
                        unde=i-1; break;
                    }
                }
            timp+=ll*3;
            l=ll; L=LL;
            if(timp>=T)
            {
                unde=i; break;
            }
        }
        if(timp<T)unde=n;
        g<<unde<<'\n';
    }
    return 0;
}
