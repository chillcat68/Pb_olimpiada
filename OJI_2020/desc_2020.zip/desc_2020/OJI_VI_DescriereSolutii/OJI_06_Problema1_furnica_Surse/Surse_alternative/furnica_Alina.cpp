//Alina Pintescu
#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("furnica.in");
ofstream fout("furnica.out");

int lungimi[10001], inaltimi[10001], c, n, T;

int main()
{
    fin>>c>>n;
    if (c==3)
        fin>>T;
    int i, j;
    for (i = 1; i<=n; i++)
        fin>>lungimi[i]>>inaltimi[i];
    if (c==2) {
        int lmax = 0;
        int lcurent = lungimi[1] + inaltimi[1];
        for (i = 2; i<=n; i++) {
            if (inaltimi[i]<inaltimi[i-1]) {
                if (lcurent>lmax)
                    lmax = lcurent;
                lcurent = lungimi[i];
            } else if (inaltimi[i]==inaltimi[i-1]) {
                lcurent += lungimi[i];
            } else if (inaltimi[i]>inaltimi[i-1]) {
                lcurent += lungimi[i] + inaltimi[i];
            }
        }
        if (lcurent>lmax)
            lmax = lcurent;
        fout<<lmax;
    } else if (c==1) {
        int t = 0;
        t = inaltimi[1] * 5 + lungimi[1] * 3;
        for (i = 2; i<=n; i++) {
            if (inaltimi[i]<inaltimi[i-1]) {
                t += (inaltimi[i-1]-inaltimi[i])*2 + lungimi[i]*3;
            } else if (inaltimi[i]==inaltimi[i-1]) {
                t += lungimi[i]*3;
            } else if (inaltimi[i]>inaltimi[i-1]) {
                t += (inaltimi[i]-inaltimi[i-1])*5 + lungimi[i]*3;
            }
            if (i==n) {
                t += inaltimi[i]*2;
            }
        }
        fout<<t;
    } else if (c==3) {
        int t = 0;
        t = inaltimi[1] * 5 + lungimi[1] * 3;
        if (t>=T) {fout<<1; return 0;}
        for (i = 2; i<=n; i++) {
            if (inaltimi[i]<inaltimi[i-1]) {
                t += (inaltimi[i-1]-inaltimi[i])*2;
                if (t>=T) {fout<<i-1; return 0;}
                t += lungimi[i]*3;
                if (t>=T) {fout<<i; return 0;}
            } else if (inaltimi[i]==inaltimi[i-1]) {
                t += lungimi[i]*3;
                if (t>=T) {fout<<i; return 0;}
            } else if (inaltimi[i]>inaltimi[i-1]) {
                t += (inaltimi[i]-inaltimi[i-1])*5;
                t += lungimi[i]*3;
                if (t>=T) {fout<<i; return 0;}
            }
            if (i==n) {
                t += inaltimi[i]*2;
            }
        }
        fout<<t;
    }
    fin.close();
    fout.close();
    return 0;
}
