//Jakab Tunde
#include <fstream>

using namespace std;

long long a1, b1, a2, b2, p,n, maxi;
ifstream fin("furnica.in");
ofstream fout("furnica.out");


int main()
{int c,i,T,ok;
 fin>>c;
 fin>>n;

 if(c==1){

   fin>>a1>>b1;
   p=a1*3+b1*5;
   for(i=2;i<=n;i++){
     fin>>a2>>b2;
     if(b1<b2)
        p=p+(b2-b1)*5;
     else if(b1>b2)
            p=p+(b1-b2)*2;
     p=p+a2*3;
    a1=a2;
    b1=b2;
   }
   p=p+b2*2;
   fout<<p;

 }else if(c==2){
         fin>>a1>>b1;
         p=a1+b1;
         for(i=2;i<=n;i++){
           fin>>a2>>b2;
           if(b1<b2)
              p=p+(b2-b1);
           else if(b1>b2){
                  if(maxi<p)maxi=p;
                  p=0;
                }
           p=p+a2;
           a1=a2;
           b1=b2;
         }
       if(maxi<p)maxi=p;
       fout<<maxi;
       }else{
          fin>>T>>a1>>b1;
          ok=1;
          p=a1*3+b1*5;
          for(i=2;i<=n && p<T;i++){
             fin>>a2>>b2;
             if(b1<b2){
               p=p+(b2-b1)*5;
               ok=1;
             }
             else if(b1>b2){
                    p=p+(b1-b2)*2;
                    ok=2;
                  }
             if(p>=T and ok==2)ok=0;
             p=p+a2*3;
             a1=a2;
             b1=b2;
          }
          if(ok==0)i--;
          fout<<i-1;
       }
 fin.close();
 fout.close();
}
