//Marinel Serban - 2020
#include <stdio.h>

FILE *fin, *fout;

struct foaie
{
   int l, h;
} F[10005];

int cerinta, N, i, p, u;
long long timp, lg, lg_max, T;

int main()
{
   fin = fopen("furnica.in", "r");
   fout = fopen("furnica.out", "w");
   fscanf(fin, "%d", &cerinta);
   if (cerinta < 3)
   {
      //citire cerinta 1 sau 2
      fscanf(fin, "%d", &N);
      for (i = 1; i <= N; i++)
         fscanf(fin, "%d %d", &F[i].l, &F[i].h);
   }
   else
   {
      //citire cerinta 3
      fscanf(fin, "%d %d", &N, &T);
      for (i = 1; i <= N; i++)
         fscanf(fin, "%d %d", &F[i].l, &F[i].h);
   }
   if (cerinta == 1)
   {
      //rezolv cerinta 1
      timp = F[1].h * 5;                     //urc
      for (i = 1; i < N; i++)
      {
         timp += F[i].l * 3;                 //orizontal pe i
         if (F[i].h < F[i+1].h)
            timp += (F[i+1].h - F[i].h) * 5; //urc pe i+1
         else
            timp += (F[i].h - F[i+1].h) * 2; //cobor pe i
      }
      timp += F[N].l * 3;                    //orizont al pe N
      timp += F[N].h * 2;                    //cobor pe N
      fprintf(fout, "%d\n", timp);
   }
   if (cerinta == 2)
   {
      //rezolv cerinta 2
      p = 1;                       //plec de la 1
      u = 1;
      lg = F[1].h;                 //urc
      while (p <= N)               // cat timp mai am unde
      {
         lg += F[p].l;             //merg pe orizontal
         u++;                      //trec la urmatoarea
         if (F[u].h >= F[p].h)     //daca e mai inalta sau egala
         {
            lg += F[u].h - F[p].h; //urc diferenta
            p++;                   //ea devine cea curenta
         }
         else                      //am terminat o secventa crescatoare
         {
            if (lg > lg_max)       //daca e mai mare
               lg_max = lg;        //retin
            p = u;                 //incep o noua seventa
            lg = 0;
         }
      }
      fprintf(fout, "%d\n", lg_max);
   }
   if (cerinta == 3)
   {
      //rezolv cerinta 3
      timp = F[1].h * 5;                 //urc
      if (timp > T)                      //am depasit
         fprintf(fout, "%d\n", 1);              //sunt pe prima
      else
      {
         for (i = 1; i < N; i++)         //parcurg pe rand cele N bucati
         {
            timp += F[i].l * 3;          //orizontal pe i
            if (timp >= T)               //am depasit
            {
               fprintf(fout, "%d\n", i);        //asta e
               break;
            }
            if (F[i].h < F[i+1].h)             //pe verticala
            {
               timp += (F[i+1].h - F[i].h) * 5;//urca pe urmatorul
               if (timp >= T)                  //am depasit
               {
                  fprintf(fout, "%d\n", i + 1);       //asta e
                  break;
               }
            }
            else
            {
               timp += (F[i].h - F[i+1].h) * 2;//coboara tot pe i
               if (timp >= T)                  // am depasit
               {
                  fprintf(fout, "%d\n", i);           //sunt TOT pe i
                  break;
               }
            }
         }
         if (timp < T)                         //inca nu am ajuns la T
            fprintf(fout, "%d\n", N);                 //voi termina pe N
      }
   }
   return 0;
}
