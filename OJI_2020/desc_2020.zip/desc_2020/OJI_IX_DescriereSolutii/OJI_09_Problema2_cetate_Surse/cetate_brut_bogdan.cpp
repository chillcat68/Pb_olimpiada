/*======================================================================================
 * Autor: stud. Iordache Ioan-Bogdan, Universitatea din Bucuresti
 * Complexitate: O(N*M*K^2)
 * Punctaj asteptat: 30p
 *====================================================================================*/
#include <fstream>
#include <tuple>
using namespace std;

const int DIM = 505;

int n, m, k, a[DIM][DIM];
long long s[DIM][DIM], sum[DIM];

int st, dr, deq[DIM];

tuple<long long, int, int, int, int> solution = make_tuple(-(1LL << 62), 0, 0, 0, 0);

inline void try_update_solution(long long sum, int i1, int j1, int i2, int j2)
{
    auto candidate = make_tuple(sum, i1, j1, i2, j2);
    if (get<0>(solution) < sum || (get<0>(solution) == sum && solution > candidate)) {
        solution = candidate;
    }
}

int main()
{
    ifstream cin("cetate.in");
    ofstream cout("cetate.out");

    int cerinta;
    cin >> cerinta;

    cin >> n >> m >> k;
    for (int i = 1; i <= n; ++i) {
        for (int j = 1; j <= m; ++j) {
            cin >> a[i][j];
            s[i][j] = a[i][j] + s[i - 1][j] + s[i][j - 1] - s[i - 1][j - 1];
        }
    }

    if (cerinta == 1) {
        for (int i = k; i <= n; ++i)
            for (int j = k; j <= m; ++j)
                try_update_solution(
                    s[i][j] - s[i - k][j] - s[i][j - k] + s[i - k][j - k],
                    i - k + 1, j - k + 1, i, j);
        goto end;
    }

    for (int i1 = 1; i1 <= n; ++i1) {
        for (int i2 = i1; i2 <= n && i2 < i1 + k; ++i2) {
            for (int j1 = 1; j1 <= m; ++j1) {
                for (int j2 = j1; j2 <= m && j2 < j1 + k; ++j2) {
                    long long sum = s[i2][j2] - s[i1 - 1][j2] - s[i2][j1 - 1]
                        + s[i1 - 1][j1 - 1];
                    try_update_solution(sum, i1, j1, i2, j2);
                }
            }
        }
    }

end:
    long long best_sum;
    int i1, i2, j1, j2;
    tie(best_sum, i1, j1, i2, j2) = solution;
    cout << best_sum << '\n';
    cout << i1 << ' ' << j1 << ' ' << i2 << ' ' << j2 << '\n';

    return 0;
}