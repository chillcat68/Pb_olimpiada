/*======================================================================================
 * Autor: stud. Iordache Ioan-Bogdan, Universitatea din Bucuresti
 * Complexitate: O(N*M*K)
 * Punctaj asteptat: 90p
 *====================================================================================*/
#include <stdio.h>

#define DIM 505
#define INF (1LL << 62)

int n, m, k, a[DIM][DIM], i, j, i1, i2;
long long sum[DIM][DIM], v[DIM], min_prefix[DIM], min_suffix[DIM];

int max(int a, int b) {
    if(a > b) return a;
    return b;
}

int main()
{

    freopen("cetate.in", "r", stdin);
    freopen("cetate.out", "w", stdout);

    int op;
    scanf("%d", &op);
    // cin >> op;
    scanf("%d %d %d", &n, &m, &k);
    // cin >> n >> m >> k;
    for ( i = 1; i <= n; ++i)
        for ( j = 1; j <= m; ++j) {
            scanf("%d", &a[i][j]);
            // cin >> a[i][j];
        }

    long long best = -INF;
    int h1 = 0, w1 = 0, h2 = 0, w2 = 0;

    if (op == 1) {
        for ( i = 1; i <= n; ++i)
            for ( j = 1; j <= m; ++j)
                sum[i][j] = a[i][j] + sum[i - 1][j] + sum[i][j - 1] - sum[i - 1][j - 1];
        for ( i = k; i <= n; ++i) {
            for ( j = k; j <= m; ++j) {
                long long curr = sum[i][j] - sum[i - k][j] - sum[i][j - k]
                    + sum[i - k][j - k];
                if (curr > best) {
                    best = curr;
                    h1 = i - k + 1, w1 = j - k + 1, h2 = i, w2 = j;
                }
            }
        }
        printf("%lld\n", best);
        printf("%d %d %d %d\n", h1, w1, h2, w2);
        // cout << best << '\n';
        // cout << h1 << ' ' << w1 << ' ' << h2 << ' ' << w2 << '\n';
        return 0;
    }

    for ( i = 1; i <= n; ++i)
        for ( j = 1; j <= m; ++j)
            sum[i][j] = a[i][j] + sum[i - 1][j];

    for ( i1 = 1; i1 <= n; ++i1) {
        for ( i2 = i1; i2 < i1 + k && i2 <= n; ++i2) {
            for ( j = 1; j <= m; ++j)
                v[j] = v[j - 1] + sum[i2][j] - sum[i1 - 1][j];

            for ( j = 1; j <= m; ++j) {
                if (j % k == 0 || v[j] < v[min_prefix[j - 1]])
                    min_prefix[j] = j;
                else
                    min_prefix[j] = min_prefix[j - 1];
            }
            for ( j = m; j >= 0; --j) {
                if (j == m || (j + 1) % k == 0 || v[j] <= v[min_suffix[j + 1]])
                    min_suffix[j] = j;
                else
                    min_suffix[j] = min_suffix[j + 1];
            }

            for ( j = 1; j <= m; ++j) {
                if (j < k) {
                    long long curr = v[j] - v[min_prefix[j - 1]];
                    if (best < curr
                        || (best == curr && h1 == i1 && min_prefix[j - 1] + 1 < w1)) {
                        best = curr;
                        h1 = i1, w1 = min_prefix[j - 1] + 1, h2 = i2, w2 = j;
                    }
                    continue;
                }
                int left = max(0, j - k);
                int right = j - 1;
                long long curr;
                int curr_w1;
                if (v[min_suffix[left]] <= v[min_prefix[right]])
                    curr = v[j] - v[min_suffix[left]],
                    curr_w1 = min_suffix[left] + 1;
                else
                    curr = v[j] - v[min_prefix[right]],
                    curr_w1 = min_prefix[right] + 1;
                if (best < curr
                    || (best == curr && h1 == i1 && curr_w1 < w1)) {
                    best = curr;
                    h1 = i1, w1 = curr_w1, h2 = i2, w2 = j;
                }
            }
        }
    }

    printf("%lld\n", best);
    printf("%d %d %d %d\n", h1, w1, h2, w2);
    // cout << best << '\n';
    // cout << h1 << ' ' << w1 << ' ' << h2 << ' ' << w2 << '\n';

    return 0;
}