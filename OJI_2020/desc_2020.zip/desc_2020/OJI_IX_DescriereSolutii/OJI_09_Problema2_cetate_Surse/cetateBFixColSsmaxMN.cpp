#include <fstream>
#include <iostream>
#define DIM 502
using namespace std;

long long a[DIM][DIM], v[DIM], sol, suma, s;
int n, m, k, i, j, i1, j1, i2, j2, t;
int d[DIM];
int p, u, c1, c2;

int main () {
    ifstream fin ("cetate.in");
    ofstream fout("cetate.out");

    fin>>t>>n>>m>>k;
    for (i=1;i<=n;i++)
        for (j=1;j<=m;j++)
            fin>>a[i][j];
    sol = 1LL*DIM*DIM*-1000000000;
    if (t == 1) {

        for (i=1;i<=n;i++)
            for (j=1;j<=m;j++)
                a[i][j] += a[i][j-1] + a[i-1][j] - a[i-1][j-1];
        for (i=k;i<=n;i++)
            for (j=k;j<=m;j++) {
                long long suma = a[i][j] - a[i-k][j] - a[i][j-k] + a[i-k][j-k];
                if (suma > sol) {
                    sol = suma;
                    i1 = i-k+1;
                    j1 = j-k+1;
                    i2 = i;
                    j2 = j;
                }
            }
        fout<<sol<<"\n";
        fout<<i1<<" "<<j1<<" "<<i2<<" "<<j2<<"\n";
    } else {
        for (j=2;j<=m;j++)
            for (i=1;i<=n;i++)
                a[i][j] += a[i][j-1];

        for (c1 = 1; c1<=m; c1++)
            for (c2 = c1; c2<=m && c2-c1+1 <= k; c2++) {
                v[1] = a[1][c2] - a[1][c1-1];

                for (i=2;i<=n;i++)
                    v[i] = a[i][c2] - a[i][c1-1];

                s = v[1];
                p = 1;
                if (v[1] > sol) {
                    sol = v[1];
                    i1 = 1;
                    j1 = c1;
                    i2 = 1;
                    j2 = c2;
                }

                for (i=2;i<=n;i++) {
                    if (s + v[i] >= v[i]) {
                        s += v[i];
                    }

                    else {
                        s = v[i];
                        p = i;
                    }

                    if (s > sol) {
                        sol = s;
                        i1 = p;
                        j1 = c1;
                        i2 = i;
                        j2 = c2;
                    }
                }
            }
        fout<<sol<<"\n";
        fout<<i1<<" "<<j1<<" "<<i2<<" "<<j2<<"\n";
    }

    return 0;
}
