#include <fstream>
using namespace std;
ifstream in("cetate.in");
ofstream out("cetate.out");
long long c,n,m,k,a[501][501],aa[501][501],s1[501][501],s2[501][501],
    s2Max[501][501],s2MaxId[501][501],s2Max1[501][501],s2MaxId1[501][501],s2Max2[501][501],s2MaxId2[501][501];
int main(){
    in>>c>>n>>m>>k;
    for(int i=1;i<=n;i++){
        for(int j=1;j<=m;j++){
            in>>a[i][j];
            aa[i][j]=a[i][j];}}
    if(c==1){
        for(int i=1;i<=n;i++){
            s1[i][1]=s1[i-1][1]+a[i][1];
            for(int j=2;j<=m;j++){
                s1[i][j]=s1[i][j-1]+s1[i-1][j]-s1[i-1][j-1]+a[i][j];}}
        long long sMax=s1[k][k],iMax=k,j1Max=k;
        for(int i=k;i<=n;i++){
            for(int j=k;j<=m;j++){
                if(sMax<s1[i][j]-s1[i][j-k]-s1[i-k][j]+s1[i-k][j-k]){
                        sMax=s1[i][j]-s1[i][j-k]-s1[i-k][j]+s1[i-k][j-k];
                        iMax=i;j1Max=j;}}}
        out<<sMax<<'\n'<<iMax-k+1<<' '<<j1Max-k+1<<' '<<iMax<<' '<<j1Max<<'\n';
        return 0;}
    long long sMax=a[1][1],iMax=1,j1Max=1,j2Max=1,kMax=1;
    for(int ik=1;ik<=k;ik++){
        for(int i=1;i<=n-ik+1;i++){
            s1[i][1]=a[i][1];
            for(int j=2;j<=m;j++){
                s1[i][j]=s1[i][j-1]+a[i][j];}
            s2[i][m]=a[i][m];
            for(int j=m-1;j>0;j--){
                s2[i][j]=s2[i][j+1]+a[i][j];}
            s2Max1[i][1]=s2[i][1];
            s2MaxId1[i][1]=1;
            for(int j=2;j<=m;j++){
                if(s2[i][j]>s2Max1[i][j-1]||j%k==1){
                    s2Max1[i][j]=s2[i][j];
                    s2MaxId1[i][j]=j;}
                else{
                    s2Max1[i][j]=s2Max1[i][j-1];
                    s2MaxId1[i][j]=s2MaxId1[i][j-1];}}
            s2Max2[i][m]=s2[i][m];
            s2MaxId2[i][m]=m;
            for(int j=m-1;j>0;j--){
                if(s2[i][j]>=s2Max2[i][j+1]||j%k==1){
                    s2Max2[i][j]=s2[i][j];
                    s2MaxId2[i][j]=j;}
                else{
                    s2Max2[i][j]=s2Max2[i][j+1];
                    s2MaxId2[i][j]=s2MaxId2[i][j+1];}}
            for(int j=1;j<=m;j++){
                if(j<=k){
                    s2Max[i][j]=s2Max1[i][j];
                    if(s2Max[i][j-1]==s2Max1[i][j]){
                        s2MaxId[i][j]=s2MaxId1[i][j-1];}
                    else{
                        s2MaxId[i][j]=s2MaxId1[i][j-1];}}
                else{   if(s2Max1[i][j]>=s2Max2[i][j-k+1]){
                            s2Max[i][j]=s2Max1[i][j];
                            s2MaxId[i][j]=s2MaxId1[i][j];}
                        else{
                            s2Max[i][j]=s2Max2[i][j-k+1];
                            s2MaxId[i][j]=s2MaxId2[i][j-k+1];}}}
            for(int j=2;j<=m;j++){
                if(s1[i][j]+s2Max[i][j]-s2[i][1]==sMax){
                    if(iMax>i || iMax==i && j1Max>s2MaxId[i][j]){
                        iMax=i;j1Max=s2MaxId[i][j];j2Max=j;kMax=ik-1;}}
                else{ if(s1[i][j]+s2Max[i][j]-s2[i][1]>sMax){
                    sMax=s1[i][j]+s2Max[i][j]-s2[i][1];
                    iMax=i;j1Max=s2MaxId[i][j];j2Max=j;kMax=ik-1;}}}
            for(int j=1;j<=m;j++){
                a[i][j]+=aa[i+ik][j];}}
    }
    out<<sMax<<'\n'<<iMax<<' '<<j1Max<<' '<<iMax+kMax<<' '<<j2Max<<'\n';
    return 0;
}
