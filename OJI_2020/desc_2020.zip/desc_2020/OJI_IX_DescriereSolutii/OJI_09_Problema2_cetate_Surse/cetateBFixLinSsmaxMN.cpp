#include <fstream>
#include <iostream>
#define DIM 502
using namespace std;

long long a[DIM][DIM], v[DIM], sol, suma, s;
int n, m, k, i, j, i1, j1, i2, j2, t;
int d[DIM];
int p, u, L1, L2;

int main () {
    ifstream fin ("cetate.in");
    ofstream fout("cetate.out");

    fin>>t>>n>>m>>k;
    for (i=1;i<=n;i++)
        for (j=1;j<=m;j++)
            fin>>a[i][j];
    sol = 1LL*DIM*DIM*-1000000000;
    if (t == 1) {

        for (i=1;i<=n;i++)
            for (j=1;j<=m;j++)
                a[i][j] += a[i][j-1] + a[i-1][j] - a[i-1][j-1];
        for (i=k;i<=n;i++)
            for (j=k;j<=m;j++) {
                long long suma = a[i][j] - a[i-k][j] - a[i][j-k] + a[i-k][j-k];
                if (suma > sol) {
                    sol = suma;
                    i1 = i-k+1;
                    j1 = j-k+1;
                    i2 = i;
                    j2 = j;
                }
            }
        fout<<sol<<"\n";
        fout<<i1<<" "<<j1<<" "<<i2<<" "<<j2<<"\n";
    } else {
        for (i=2;i<=n;i++)
            for (j=1;j<=m;j++)
                a[i][j] += a[i-1][j];

        for (L1 = 1; L1<=n; L1++)
            for (L2 = L1; L2<=n && L2-L1+1 <= k; L2++) {
                v[1] = a[L2][1] - a[L1-1][1];

                for (i=2;i<=m;i++)
                    v[i] = a[L2][i] - a[L1-1][i];

                s = v[1];
                p = 1;
                if (v[1] > sol) {
                    sol = v[1];
                    i1 = L1;
                    j1 = 1;
                    i2 = L2;
                    j2 = 1;
                }

                for (i=2;i<=m;i++) {
                    if (s + v[i] >= v[i]) {
                        s += v[i];
                    }

                    else {
                        s = v[i];
                        p = i;
                    }

                    if (s > sol) {
                        sol = s;
                        i1 = L1;
                        j1 = p;
                        i2 = L2;
                        j2 = i;
                    }
                }

            }
        fout<<sol<<"\n";
        fout<<i1<<" "<<j1<<" "<<i2<<" "<<j2<<"\n";
    }

    return 0;
}
