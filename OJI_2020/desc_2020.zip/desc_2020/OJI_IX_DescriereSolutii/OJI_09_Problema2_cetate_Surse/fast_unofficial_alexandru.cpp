/**
Alexandru Petrescu
O(N^2 * K * logN)
featuring: aib
**/

#include <cstdio>
#include <cctype>
#include <cstring>
#include <algorithm>

FILE *fin = fopen("cetate.in", "r"), *fout = fopen("cetate.out", "w");

#define BUF_SIZE 1 << 17

int pos = BUF_SIZE;
char buf[BUF_SIZE];

inline char nextch() {
    if (pos == BUF_SIZE) fread(buf, BUF_SIZE, 1, fin), pos = 0;
    return buf[pos++];
}

inline int read() {
    char ch = nextch();
    while (ch != '-' && !isdigit(ch)) ch = nextch();
    int s = 1;
    if (ch == '-') s = -1, ch = nextch();
    int x = ch - '0';
    while (isdigit(ch = nextch())) x = 10 * x + ch - '0';
    return s * x;
}

#define LIM 501

int n;
long long aib[LIM], s[LIM][LIM];

inline void update(int p, long long x) {
    while (p <= n) {
        aib[p] = std::max(aib[p], x);
        p += p & (-p);
    }
}

inline long long query(int p) {
    long long ans = aib[p];
    do {
        p -= p & (-p);
        ans = std::max(ans, aib[p]);
    } while (p);
    return ans;
}

int main() {
    int c = read();
    int nrlin = read();
    int nrcol = read();
    int k = read();

    if (c != 2)
        return 0;
    n = nrcol;

    for (int i = 1; i <= nrlin; i++)
        for (int j = 1; j <= nrcol; j++)
            s[i][j] = read() + s[i - 1][j] + s[i][j - 1] - s[i - 1][j - 1];

    long long ans = s[1][1];
    int sol1 = 1, sol2 = 1, sol3 = 1, sol4 = 1;
    for (int i = 1; i <= nrlin; i++) {
        for (int l = i; l <= nrlin && l - i < k; l++) {
            memset(aib, 0x80, sizeof(aib[0]) * (nrcol + 1));
            for (int j = nrcol; j > 0; j--) {
                update(j, s[l][j] - s[i - 1][j]);
                long long val = query(std::min(j + k - 1, nrcol)) - (s[l][j - 1] - s[i - 1][j - 1]);
                if (val > ans || (val == ans && i == sol1 && j < sol2)) sol1 = i, sol2 = sol4 = j, sol3 = l, ans = val;
            }
        }
    }

    while (s[sol3][sol4] - s[sol3][sol2 - 1] - s[sol1 - 1][sol4] + s[sol1 - 1][sol2 - 1] != ans)
        sol4++;

    fprintf(fout, "%lld\n%d %d %d %d\n", ans, sol1, sol2, sol3, sol4);

    fclose(fin);
    fclose(fout);
    return 0;
}
