#include <fstream>

using namespace std;

ifstream fin ("buldo.in");
ofstream fout("buldo.out");
long long a, b, c, i, sol, n, s;
int main () {
    fin>>n;
    fin>>a;
    if (n == 1) {
        fout<<a<<"\n";
        return 0;
    }
    fin>>b;
    s = a;
    sol = a;
    s += b;
    sol = min(sol, s/2);
    for (i=3;i<=n;i++) {
        fin>>c;
        s += c;
        sol = min(sol, s/i);
        a = b;
        b = c;
    }
    fout<<sol;
    return 0;
}

