#include <fstream>

using namespace std;

ifstream fin ("buldo.in");
ofstream fout("buldo.out");
int f[2000010];
int n, sol, i, ok, mod;
long long lama;
int main () {
    fin>>n;
    for (i=1;i<=n;i++)
        fin>>f[i];

    for (sol = f[1]; sol >= 1; sol--) {
        int ok = 1;
        lama = f[1]-sol;
        for (i=2;i<=n;i++)
            if (f[i]+lama < sol) {
                ok = 0;
                break;
            } else {
                lama = f[i]+lama-sol;
            }
        if (ok) {
            fout<<sol;
            return 0;
        }
    }
    fout<<f[1];
    return 0;
}

