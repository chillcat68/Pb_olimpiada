#include <fstream>
#include <cmath>
#define vMax 100001
using namespace std;
ifstream in("buldo.in");
ofstream out("buldo.out");
long long  n,a[vMax];
int main(){
    in>>n;
    for(long long i=1;i<=n;i++){
        in>>a[i];
    }
    long long c=0,h=a[1];
    for(long long i=2;i<=n;i++){
        if(a[i]-h+c>=0){
            c+=a[i]-h;
        }else{
            long long d=a[i]-h;//dif de acoperit
            long long dh=floor((double(d+c)/i));//dif cu care trebuie scazuta h
            c-=dh*(i-1);//actualizare cupa
            h+=dh;//actualizare h
            if(a[i]-h+c<0)out<<"err"<<i;
            c+=a[i]-h;
        }
    };
    out << h << endl;
    return 0;
}
