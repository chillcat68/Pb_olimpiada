//Bodnariuc Danut
//brute force O(n*valoareMaximaElemente)
//Processor	Intel(R) Core(TM) i3-2348M CPU @ 2.30GHz, 2300 Mhz, 2 Core(s), 4 Logical Processor(s)
//buldo0..buldo9 < 0.056 sec
//buldo10 = 5 sec
#include <fstream>
#define MAX 100003
using namespace std;
ifstream fi("buldo.in");
ofstream fo("buldo.out");
long long h[MAX],N,i,C,Lama;
bool gasitC;
int main()
{
    fi>>N;
    for(i=1;i<=N;i++)fi>>h[i];
    C=1; //se porneste initial lama la valoarea C=1
    gasitC=false; //nu avem solutie
    while(gasitC==false){
        Lama=0;
        for(i=1;i<=N;i++)
          {
              if(h[i]>=C)Lama+=h[i]-C;
              else
                if(Lama>=C-h[i])Lama-=C-h[i];
                else break;
          }
          if(i==N+1)//nivelare reusita,
             C++;    //deci incercam cu o lama mai mare
          else gasitC=true;  //am gasit solutia
    }
    fo<<C-1;
    return 0;
}
