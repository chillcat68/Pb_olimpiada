#include <fstream>
using namespace std;
int main()
{
    ifstream in("buldo.in");
    ofstream out("buldo.out");
    int  n,p;
    long long x,y,w,sp,t;
    in>>n>>x>>y;
    w=x;
    sp=x+y;
    if(w>sp/2)
        w=sp/2;
    n=n-2;
    p=3;
    while(n--)
    {
        //int t=1+(1ll*x*y+x+y)%z;
        in>>t;
        sp=sp+t;
        if(w>sp/p)
            w=sp/p;
        p++,x=y,y=t;
    }
    out<<w<<'\n';
    out.close();
    return 0;
}
