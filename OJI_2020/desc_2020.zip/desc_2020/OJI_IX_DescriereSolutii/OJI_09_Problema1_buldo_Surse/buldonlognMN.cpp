#include <fstream>

using namespace std;
int f[2000010];
long long lama;
int n, i, mod, st, dr, mid, ok;
int main () {
    ifstream fin ("buldo.in");
    ofstream fout("buldo.out");
    fin>>n;
    for (i=1;i<=n;i++)
        fin>>f[i];

    st = 1;
    dr = f[1];
    while (st <= dr) {
        int mid = (st+dr)/2;
        lama = f[1] - mid;
        ok = 1;
        for (i=2;i<=n;i++) {
            if (f[i] + lama < mid) {
                ok = 0;
                break;
            } else {
                lama = f[i] + lama - mid;
            }
        }
        if (ok)
            st = mid+1;
        else
            dr = mid-1;
    }
    fout<<dr;
    return 0;
}
