#include <bits/stdc++.h>

using namespace std;
ifstream f("buldo.in");
ofstream g("buldo.out");
const int N = 100010;
const int oo = 2000000000;
int n,h[N],c[N],v[N],m;
int main()
{
    f>>n;
    for(int i=1;i<=n;i++)
        f>>h[i];
    v[m]=oo;
    c[m]=0;
    for(int i=n;i>=1;i--)
    {
        if(h[i]<v[m])
        {
            m++;v[m]=h[i];c[m]=1;
            continue;

        }
        int r=h[i]-v[m];c[m]++;
        /// cat timp am suficient sa ridic ultimul nivel la penultimul nivel
        do
        {
            int64_t need = 1LL*c[m]*(v[m-1]-v[m]);
            if(need<=1LL*r)
            {
                c[m-1]+=c[m];
                r-=need;
                m--;
                continue;
            }
            int hplus=r/c[m];
            v[m]+=hplus;
            r=r%c[m];
            if(r==0)
                break;
            m++;
            v[m]=v[m-1];
            v[m-1]++;
            c[m]=c[m-1]-r;
            c[m-1]=r;
            break;

        }
        while(1);
    }
    g<<v[m];
    return 0;
}
