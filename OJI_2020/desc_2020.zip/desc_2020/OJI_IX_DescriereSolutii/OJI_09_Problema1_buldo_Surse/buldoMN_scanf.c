#include <stdio.h>

long long a, b, c, MOD, i, sol, n, s;

long long min(long long a, long long b) {
    if(a < b) return a;
    return b;
}

int main () {
    freopen("buldo.in", "r", stdin);
    freopen("buldo.out", "w", stdout);
    scanf("%lld ", &n);
    scanf("%lld %lld", &a, &b);
    s = a;
    sol = a;
    s += b;
    sol = min(sol, s/2);
    for (i=3;i<=n;i++) {
        ///f[i] = 1 + (1LL*f[i-1]*f[i-2] + f[i-1] + f[i-2]) % MOD;
        scanf("%lld ", &c);
        s += c;
        sol = min(sol, s/i);
        a = b;
        b = c;
    }
    printf("%lld\n", sol);
    return 0;
}
