//Bodnariuc Danut
//brute force O(n*n) -45p
//idee: se parcurge matricea spira cu spira element cu element
#include <fstream>
#define MAX 100003
using namespace std;
ifstream fi("spiralmatrix.in");
ofstream fo("spiralmatrix.out");
int elem_cautat1,elem_cautat2,i,k,n,sp,t,j,sol1i,sol1j,sol2i,sol2j;
bool gasit;
int main()
{
    fi>>n;
    if(n%2==0) {elem_cautat1=n*n/2;elem_cautat2=n*n/2+1;}
    else {elem_cautat1=n*n/2;elem_cautat2=n*n/2+2;}
    k=0;
    sp=n/2;  //sp- numar spire
    gasit=false;
    for(t=1;t<=sp and gasit==false;t++){
        for(j=t;j<=n-t+1 and gasit==false;j++) //linia t
          { k++;
            if(k==elem_cautat1){sol1i=t;sol1j=j;}
            if(k==elem_cautat2){sol2i=t;sol2j=j;gasit=true;}
          }
        for(i=t+1;i<=n-t+1 and gasit==false;i++) //col n-t+1
          { k++;
            if(k==elem_cautat1){sol1i=i;sol1j=n-t+1;}
            if(k==elem_cautat2){sol2i=i;sol2j=n-t+1;gasit=true;}
          }
        for(j=n-t;j>=t and gasit==false;j--) //linia n-t+1
          { k++;
            if(k==elem_cautat1){sol1i=n-t+1;sol1j=j;}
            if(k==elem_cautat2){sol2i=n-t+1;sol2j=j;gasit=true;}
          }
        for(i=n-t;i>t and gasit==false;i--) //col n-t+1
          { k++;
            if(k==elem_cautat1){sol1i=i;sol1j=t;}
            if(k==elem_cautat2){sol2i=i;sol2j=t;gasit=true;}
          }
    }
    fo<<sol1i<<" "<<sol1j<<'\n';
    fo<<sol2i<<" "<<sol2j<<'\n';
    return 0;
}
