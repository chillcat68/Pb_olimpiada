#include <fstream>
#include <cmath>
using namespace std;
ifstream in("spiralmatrix.in");
ofstream out("spiralmatrix.out");
int l0=1,l1=1,l2=1,c0=1,c1=1,c2=1;
int main(){
    long long n,nc=0;
    int l=1,c=0,dl=0,dc=1;
    in>>n;
    //cautare binara p2
    long long st=1,dr=n,p2=(st+dr)/2;
    while(st<dr){
        p2=(st+dr)/2;
        if(1+4*p2*n-4*p2*p2<n*n/2)st=p2+1;
        else if(1+4*p2*n-4*p2*p2>n*n/2)dr=p2-1;
             else dr=st=p2;
    }
    p2=min(st,dr)+1;
    if(1+4*(p2-1)*n-4*(p2-1)*(p2-1)>=n*n/2)p2--;
    nc=n*n/2-(1+4*(p2-1)*n-4*(p2-1)*(p2-1));
    if(nc<n-(2*p2-1)){
        dl=0;dc=1;
        l=p2;
        c=nc+p2;
    }else{if(nc<2*(n-(2*p2-1))){
        dl=1;dc=0;
        l=p2+nc-(n-(2*p2-1));
        c=p2+n-(2*p2-1);
    }else{if(nc<3*(n-(2*p2-1))){
        dl=0;dc=-1;
        l=n-p2+1;
        c=n-p2+1-(nc-2*(n-(2*p2-1)));
    }else{
        dl=-1;dc=0;
        c=p2;
        l=p2+n-(2*p2-1)-(nc-3*(n-(2*p2-1)));
    }}}
    l0=l;c0=c;
    if(nc==4*(n-(2*p2-1))-1){dl=0;dc=1;}
    else{if(l+dl<p2 || n-p2+1<l+dl || c+dc<p2 || n-p2+1<c+dc){
            if(dl==0 && dc==1){dl=1;dc=0;}
            else{if(dl==1 && dc==0){dl=0;dc=-1;}
                  else{if(dl==0 && dc==-1){dl=-1;dc=0;}
                       else{dl=0;dc=1;}}}}}
    l=l+dl;c=c+dc;
    l1=l;c1=c;
    if(l+dl<p2 || n-p2+1<l+dl || c+dc<p2 || n-p2+1<c+dc){
        if(dl==0 && dc==1){dl=1;dc=0;}
        else{if(dl==1 && dc==0){dl=0;dc=-1;}
              else{if(dl==0 && dc==-1){dl=-1;dc=0;}
                   else{dl=0;dc=1;}}}}
    l=l+dl;c=c+dc;
    l2=l;c2=c;
    out <<  l0 << ' ' << c0 << endl;
    if(n%2==0)out <<  l1 << ' ' << c1 << endl;
    else out <<  l2 << ' ' << c2 << endl;
    return 0;}
