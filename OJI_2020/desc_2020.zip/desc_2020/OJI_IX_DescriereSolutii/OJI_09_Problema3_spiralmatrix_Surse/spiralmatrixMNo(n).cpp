#include <fstream>

using namespace std;
long long n, i, j;
void calcul(long long poz, long long &i, long long &j) {
    long long k = n;
    long long d = 1;
    while (poz > 4*k-4) {
        poz -= (4*k-4);
        k -= 2;
        d++;
    }

    if (poz <= k) {
        i = d;
        j = d+poz-1;
    } else
        if (poz <= 2*k-1) {
            poz -= (k-1);
            i=d+poz-1;
            j=n-d+1;
        } else
            if (poz <= k+k-1+k-1) {
                poz -= (2*k-2);
                i = n-d+1;
                j = n-d+1-poz+1;
            } else {
                i = d+(4*k-4-poz+1);
                j = d;
            }

}
/**
 1  2  3  4 5
16 17 18 19 6
15 24 25 20 7
14 23 22 21 8
13 12 11 10 9
**/

int main () {
    ifstream fin ("spiralmatrix.in");
    ofstream fout("spiralmatrix.out");
    fin>>n;
    /**
    long long x = 0, k, j;
    long long a[100][100];
    for (k=1;k<=n/2;k++) {
        for (i=k;i<=n-k+1;i++)
            a[k][i] = ++x;
        for (i=k+1;i<=n-k+1;i++)
            a[i][n-k+1] = ++x;
        for (i=n-k;i>=k;i--)
            a[n-k+1][i] = ++x;
        for (i=n-k;i>k;i--)
            a[i][k] = ++x;
    }
    if (n%2 == 1)
        a[n/2+1][n/2+1] = ++x;
    for (i=1;i<=n;i++) {
        for (j=1;j<=n;j++)
            fout<<a[i][j]<<" ";
        fout<<"\n";
    }
**/
    calcul(n*n/2, i, j);
    fout<<i<<" "<<j<<"\n";
    if (n%2 == 0)
        calcul(n*n/2+1, i, j);
    else
        calcul(n*n/2+2, i, j);
    fout<<i<<" "<<j<<"\n";


    return 0;
}
