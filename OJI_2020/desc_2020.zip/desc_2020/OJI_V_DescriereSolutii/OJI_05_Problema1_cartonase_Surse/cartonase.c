#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
int N, R, X, Y, K, P, i, Max, Lc, Nr, Nrs,x, y;
int main()
{
    freopen("cartonase.in", "r",stdin);
    freopen("cartonase.out","w",stdout);
    scanf("%d\n",&P);
    assert(P>0 && P<4);
    scanf("%d\n",&N);
    assert(N>0 && N<501);
    Nr = Max = 0;  Lc = 1; Nrs = 0;
    scanf("%d %d", &X, &Y);
    assert(X>0 && X<10001);
    assert(Y>0 && Y<10001);
   for(i = 2; i <= N ; i++){
        scanf("%d %d", &x, &y);
        assert(x>0 && x<10001);
        assert(y>0 && y<10001);
        if (Y == x){
            Nr++;
            Lc++;
        }
        else Lc = 1;
        if(Lc > Max) {Max = Lc; Nrs = 1;}
        else if (Lc == Max) Nrs++;
        Y = y;
    }
    if(P==1) printf("%d\n", Nr);
    else if (P==2 ) printf("%d\n", Max);
         else printf("%d\n", Nrs);
return 0;
}

