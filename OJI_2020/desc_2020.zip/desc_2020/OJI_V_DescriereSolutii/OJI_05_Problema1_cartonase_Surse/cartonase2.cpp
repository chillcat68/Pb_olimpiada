#include<fstream>
using namespace std;
int n,s,d,nr,c,S,D,lc,lmax;
ifstream f("cartonase.in");
ofstream g("cartonase.out");
int main()

{
    f>>c>>n;
    ///cerinta 1
    if(c==1)
    {   f>>s>>d;
        for(int i=2;i<=n;i++)
        {
            f>>S>>D;
            if(d==S) nr++;
            s=S;d=D;
        }
        g<<nr<<endl;
    }
    else
    { ///cerintele 2 si 3
      f>>s>>d;lmax=1;nr=1;lc=1;
      for(int i=2;i<=n;i++)
      {
          f>>S>>D;
          if(d==S) lc++;
          else
            lc=1;
          if(lc>lmax)
          {lmax=lc;nr=1;}
          else
            if(lc==lmax) nr++;
        s=S;d=D;
        }
        ///afisare cerinta 2
       if(c==2)
        g<<lmax<<endl;
        else g<<nr<<endl; ///afisare cerinta 3
    }
    f.close();
    g.close();
    return 0;
}

