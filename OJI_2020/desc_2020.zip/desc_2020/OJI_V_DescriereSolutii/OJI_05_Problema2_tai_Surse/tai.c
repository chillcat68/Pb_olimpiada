#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#define inf 1000000000

int N, R, X, K, P, j, i, ok, cif, x, d, pz, p, a, b, c, Max,cm, nc, Nr, p1, k;
int main()
{
    freopen("tai.in", "r",stdin);
    freopen("tai.out","w",stdout);
    scanf("%d\n",&P);
    assert(P>0 && P<4);
    scanf("%d\n",&N);
    assert(N>0 && N<101);
    if(P==1)
    {
        Max = 0;
        for( i = 1; i <= N ; i++)
        {
            scanf("%d", &X);
            assert(X>=0 && X<=inf);
            if(X<2)
                ok = 0;
            else
                ok = 1;

            for(d = 2; d * d <= X && ok; d++)
                if(X%d == 0)
                    ok = 0;

            if(ok && X > Max)
                Max = X;
        }
        printf("%d\n", Max);
    }
    if(P==2)
    {
        Max = 0;
        for( i = 1; i <= N ; i++)
        {
            scanf("%d", &x);
            assert(x>=0 && x<=inf);
            pz = 1;
            ok = 1;
            while (x/pz > 0)
                pz*=10;
            p = pz/10;
            while (p>9)
            {
                a = x % p;
                b = x / p;

                ok = 1;
                for(d = 2; d * d <= a && ok; d++)
                    if(a % d == 0)
                        ok = 0;

                if(a>1 && ok && a > Max)
                    Max = a;

                ok = 1;
                for(d = 2; d * d <= b && ok; d++)
                    if(b % d == 0)
                        ok = 0;

                if(b>1 && ok && b > Max)
                    Max = b;
                p/=10;
            }
        }
        printf("%d\n", Max);
    }
    if(P==3)
    {
        Max = 0;
        for( k = 1; k <= N ; k++)
        {
            scanf("%d", &X);
            assert(X>=0 && X<=inf);
            nc = 0;
            pz = 1;
            while (X/pz > 0)
            {
                pz*=10;
                nc++;
            }
            pz = pz/10;
            p1 = p = pz;
            for(i = 1; i< nc -1; i++)
            {
                c = X / p1;
                x = X % p1;
                p = p1 / 10;

                ok = 1;
                for(d = 2; d * d <= c && ok; d++)
                    if(c % d == 0)
                        ok = 0;

                if(c>1 && ok && c > Max)
                    Max = c;
                while (p>9)
                {
                    a = x % p;
                    b = x / p;

                    ok = 1;
                    for(d = 2; d * d <= a && ok; d++)
                        if(a % d == 0)
                            ok = 0;

                    if(a>1 && ok && a > Max)
                        Max = a;

                    ok = 1;
                    for(d = 2; d * d <= b && ok; d++)
                        if(b % d == 0)
                            ok = 0;

                    if(b>1 && ok && b > Max)
                        Max = b;
                    p/=10;
                }
                p1 /=10;
            }
        }
        printf("%d\n", Max);
    }

    return 0;
}
