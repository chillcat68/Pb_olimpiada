#include<fstream>
using namespace std;
ifstream f("tai.in");
ofstream g("tai.out");
bool prim(long long x)
{
    if(x==2) return 1;
    if(x%2==0) return 0;
    if(x<2) return 0;
    for(int d=3;d*d<=x;d=d+2)
        if(x%d==0) return 0;
    return 1;
}
int nrc(long long x)
{
    int N=0;
    while(x)
    {
        N++;
        x/=10;
    }
    return N;
}
long long c,x,i,n,max_p,n1,n2,n3,Nc;
long long pz[]={1,10,100,1000,10000,100000,1000000,10000000,100000000,1000000000,10000000000};
int main()
{
    f>>c;
    if(c==1)
    {
        f>>n;
        for(i=1;i<=n;i++)
        {
            f>>x;
            if(prim(x))
                max_p=max(x,max_p);
        }
        if(max_p==1) max_p=0;
        g<<max_p<<endl;
    }
    else
        if(c==2)
    {
        f>>n;
        for(i=1;i<=n;i++)
        {
            f>>x;
            Nc=nrc(x);
            for(int j=1;j<Nc;j++)
            {
                n1=x/pz[j];n2=x%pz[j];
                if(prim(n1)) max_p=max(max_p,n1);
                if(prim(n2)) max_p=max(max_p,n2);
            }
        }
          g<<max_p<<endl;
    }
    else
    {
         f>>n;

        for(i=1;i<=n;i++)
        {
            f>>x;
            Nc=nrc(x);
            long long X=x;
            for(int j=1;j<Nc-1;j++)

            {
                n3=x%pz[j];
                x=x/pz[j];
                int Nrc=Nc-j;
                for(int k=1;k<Nrc;k++)
                {n2=x%pz[k];n1=x/pz[k];
               // g<<n1<<" "<<n2<<" "<<n3<<endl;
                if(prim(n1)) max_p=max(max_p,n1);
                if(prim(n2)) max_p=max(max_p,n2);
                if(prim(n3)) max_p=max(max_p,n3);
                }
                x=X;
            }

        }
         g<<max_p<<endl;
    }
    f.close();
    g.close();
    return 0;
}
