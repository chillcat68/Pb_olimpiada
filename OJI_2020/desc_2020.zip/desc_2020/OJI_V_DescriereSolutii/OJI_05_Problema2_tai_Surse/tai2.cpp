#include <fstream>
using namespace std;

int Prim(int n)
{
    if (n <= 1) return 0;
    if (n == 2) return 1;
    if (n % 2 == 0) return 0;
    for (int i = 3; i * i <= n; i += 2)
        if (n % i == 0) return 0;
    return 1;
}

int main()
{
    int x, n, task, p, q, M = 0;
    ifstream fin("tai.in");
    ofstream fout("tai.out");
    fin >> task >> n;
    if (task == 1)
    {
        while (n--)
        {
            fin >> x;
            if (Prim(x) && x > M) M = x;
        }
    }
    else if (task == 2)
    {
        while (n--)
        {
            fin >> x;
            p = 10;
            while (x / p > 0)
            {
                if (Prim(x / p) && M < x / p) M = x / p;
                if (Prim(x % p) && M < x % p) M = x % p;
                p *= 10;
            }
        }
    }
    else /// task = 3
    {
        while (n--)
        {
            fin >> x;
            for (p = 100; x / p > 0; p *= 10)
                for (q = 10; q < p; q *= 10)
                {
                    if (Prim(x / p) && M < x / p) M = x / p;
                    if (Prim(x % p / q) && M < x % p / q) M = x % p / q;
                    if (Prim(x % q) && M < x % q) M = x % q;
                }
        }
    }
    fout << M << "\n";
    fin.close();
    fout.close();
    return 0;
}
