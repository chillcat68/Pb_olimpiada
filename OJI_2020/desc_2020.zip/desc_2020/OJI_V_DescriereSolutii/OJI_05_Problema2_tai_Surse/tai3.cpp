#include <fstream>

using namespace std;
ifstream f("tai.in");
ofstream g("tai.out");
int c,n,a;
bool eprim(int);
int nr_cifre(int);
int putere(int);
int main()
{
    f>>c>>n;
    if(c==1)
    {
        int sol=0;
        for(int i=1; i<=n; i++)
        {
            f>>a;
            if(eprim(a))
                sol=max(sol,a);
        }
        g<<sol;
    }
    if(c==2)
    {
        int sol=0;
        for(int i=1; i<=n; i++)
        {
            f>>a;
            int cnt=nr_cifre(a)-1;
            for(int j=1; j<=cnt; j++)
            {
                int aux=putere(j);
                int b=a%aux,c=a/aux;
                if(eprim(b))
                    sol=max(sol,b);
                if(eprim(c))
                    sol=max(sol,c);
            }
        }
        g<<sol;
    }
    if(c==3)
    {
        int sol=0;
        for(int i=1; i<=n; i++)
        {
            f>>a;
            int cnt=nr_cifre(a)-1;
            for(int j=1; j<=cnt; j++)
            {
                int aux=putere(j);
                int b=a%aux;
                int c=a/aux;
                if(b>=10)
                {
                    int cntt=nr_cifre(b)-1;
                    for(int jj=1; jj<=cntt; jj++)
                    {
                        int auxx=putere(jj);
                        int bb=b%auxx;
                        int cc=b/auxx;
                        if(eprim(bb))
                            sol=max(sol,bb);
                        if(eprim(cc))
                            sol=max(sol,cc);
                    }
                    if(eprim(c)) sol=max(sol,c);
                }
                else
                {
                    int cntt=nr_cifre(c)-1;
                    for(int jj=1; jj<=cntt; jj++)
                    {
                        int auxx=putere(jj);
                        int bb=c%auxx;
                        int cc=c/auxx;
                        if(eprim(bb))
                            sol=max(sol,bb);
                        if(eprim(cc))
                            sol=max(sol,cc);
                    }
                    if(eprim(b)) sol=max(sol,b);

                }
            }
        }
        g<<sol;
    }
    return 0;
}
bool eprim(int x)
{
    if(x==1||x==0)
        return false;
    if(x==2)
        return true;
    if(x%2==0)
        return false;
    for(int i=3; i*i<=x; i+=2)
        if(x%i==0)
            return false;
    return true;
}
int nr_cifre(int x)
{
    int cnt=0;
    while(x)
    {
        x/=10;
        cnt++;
    }
    return cnt;
}
int putere(int x)
{
    int p=1;
    while(x)
    {
        p*=10;
        x--;
    }
    return p;
}
