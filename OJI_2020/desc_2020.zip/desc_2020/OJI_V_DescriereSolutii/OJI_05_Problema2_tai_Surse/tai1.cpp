#include <iostream>
#include <fstream>
using namespace std;
ifstream in("tai.in");
ofstream out("tai.out");

int prim(int x)
{ int ok,d;
    ok=1;
        if(x<=1)ok=0;
        for(d=2;d*d<=x&&ok;++d)
            if(x%d==0)ok=0;
    return ok;
}

int main()
{
    int N,i,x,ok,xmax=0,C,d,y,x1,x2,p,p2,x21,x22;
    in>>C>>N;
    if(C==1)
    {
    for(i=1;i<=N;++i)
    {
        in>>x;

      if(prim(x))if(x>xmax)xmax=x;
    }
    out<<xmax;
    }
    if(C==2)
    {for(i=1;i<=N;++i)
    {
        in>>y;
        p=10;
        while(p<y)
        {
            x1=y/p;
            x2=y%p;
            if(prim(x1))if(x1>xmax)xmax=x1;

            if(prim(x2))if(x2>xmax)xmax=x2;
            p=p*10;
        }
    }
    out<<xmax;

    }
    if(C==3)
    {
    for(i=1;i<=N;++i)
    {
        in>>y;
        p=100;
        while(p<y)
        {
            x1=y/p;
            x2=y%p;
            if(prim(x1))if(x1>xmax)xmax=x1;

             p2=10;
        while(p2<x2)
        {
            x21=x2/p2;
            x22=x2%p2;
            if(prim(x21))if(x21>xmax)xmax=x21;
            if(prim(x22))if(x22>xmax)xmax=x22;
            p2=p2*10;
        }
            p=p*10;
        }
    }
    out<<xmax;

    }

    return 0;
}

