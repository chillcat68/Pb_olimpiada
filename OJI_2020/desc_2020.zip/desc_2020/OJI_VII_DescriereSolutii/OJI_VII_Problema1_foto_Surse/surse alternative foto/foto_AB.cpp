#include <fstream>

using namespace std;
int a[103][103];
int main()
{
    int i,j,nr=0,nrmax=0,c, hmax=0,nrfulgere=0,n,m;
    ifstream f("foto.in");
    ofstream g("foto.out");
    f>>c>>n>>m;
    for(i=1; i<=n; i++){nr=0;
        for(j=1; j<=m; j++)
        {
            f>>a[i][j];
            if(a[i][j]==0)
            {
                nr++;
                if(nr>nrmax)
                    nrmax=nr;
            }
            else
            {
                nr=0;
                if(a[i-1][j]!=0)
                    a[i][j]=a[i-1][j]+1;
                else if(a[i-1][j-1]!=0)
                    a[i][j]=a[i-1][j-1]+1;
                else if(a[i-1][j+1]!=0)
                    a[i][j]=a[i-1][j+1]+1;
              if(hmax<a[i][j])
                hmax=a[i][j];
              if (a[i][j]==1)nrfulgere++;
            }
        }
    }
    
        if(c==1)g<<nrmax;
         else g<<nrfulgere<<" "<<hmax;
    return 0;
}
