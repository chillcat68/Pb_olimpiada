#include <iostream>
#include <fstream>

using namespace std;

ifstream f("foto.in");
ofstream g("foto.out");

int i,j,n,m,a[101][101],k,maxim,C,fulgere;
int main()
{
    f>>C;
    if(C==1)
    {
        f>>n>>m;
        for(i=1; i<=n; i++)
        {
            k=0;
            for(j=1; j<=m; j++)
            {
                f>>a[i][j];
                if(a[i][j]==0)
                    k++;
                else
                {
                    if(k>maxim)
                        maxim=k;
                    k=0;
                }
            }
 	    if(k>maxim) maxim=k;
        }
        g<<maxim;
    }
    else
    {
        f>>n>>m;
        for(i=1; i<=n; i++)
        {
            for(j=1; j<=m; j++)
            {
                f>>a[i][j];
                if(a[i][j])
                {
                    if(a[i-1][j-1]==0 and a[i-1][j]==0 and a[i-1][j+1]==0)
                        fulgere++;
                    if(a[i-1][j-1])
                        a[i][j]=a[i-1][j-1]+1;

                    if(a[i-1][j])
                        a[i][j]=a[i-1][j]+1;

                    if(a[i-1][j+1])
                        a[i][j]=a[i-1][j+1]+1;
                    if(a[i][j]>maxim)
                        maxim=a[i][j];
                }

            }
        }
        g<<fulgere<<" "<<maxim;
    }

    return 0;
}
