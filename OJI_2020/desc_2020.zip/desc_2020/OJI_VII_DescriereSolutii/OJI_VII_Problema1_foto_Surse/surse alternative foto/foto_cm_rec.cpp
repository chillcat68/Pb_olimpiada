#include <fstream>
#include <iostream>
using namespace std;
ifstream f("foto.in");
ofstream g("foto.out");
int a[102][102],h, N, M;
void caut(int i, int j)
{
    a[i][j]=0;
    h++;
    if(a[i+1][j-1])caut(i+1,j-1);
    else if(a[i+1][j])caut(i+1,j);
    else if(a[i+1][j+1])caut(i+1,j+1);
}


int main()
{
    int C;//,N,M;
    f>>C>>N>>M;

    if(C==1)
    {
        int x,P=0,i,j,p=0;
        for(i=1; i<=N; i++)
        {
            p=0;
            for(j=1; j<=M; j++)
            {
                f>>x;
                if(x==0)p++;
                else
                {
                    P=max(p,P);
                    p=0;
                }
            }
            P=max(P,p);
        }
        g<<P<<endl;
    }
    else
    {
        int H=0,F=0,i,j,r,c;
        for(i=1; i<=N; i++)
            for(j=1; j<=M; j++)
                f>>a[i][j];

        for(r=1; r<=N; r++)
            for(c=1; c<=M; c++)
                if(a[r][c]==1)
                {
                    F++;
                    h=0;
                    caut(r,c);
                    H=max(h,H);
                }

        g<<F<< " "<<H;
    }
    return 0;
}

