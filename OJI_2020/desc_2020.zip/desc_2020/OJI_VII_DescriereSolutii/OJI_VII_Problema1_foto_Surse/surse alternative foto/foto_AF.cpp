#include <iostream>
#include <fstream>
using namespace std;
ifstream fin("foto.in");
ofstream fout("foto.out");
int a[105][105],i,j,n,m,c,k,mx,kmax,fmax,nr,kf;
int dl[]={-1,-1,-1,0,1,1,1,0};
int dc[]={-1,0,1,1,1,0,-1,-1};

void lee(int a[][105],int n,int m,int l, int c, int &nr)
{
    int i,ln,cn;
    a[l][c]=0;nr++;
    for(i=0;i<=7;i++)
    {
        ln=l+dl[i];
        cn=c+dc[i];
        if(a[ln][cn]==1)
            lee(a,n,m,ln,cn,nr);
    }

}

int main()
{
    fin>>c;
    fin>>n>>m;
    mx=0;kmax=0;
    for(i=1; i<=n; i++)
    {
        k=0;
        for(j=1; j<=m; j++)
        {
            fin>>a[i][j];
            if(a[i][j]==0)k++;
            else
                {if(k>kmax)
                kmax=k;
                k=0;}
        }
        if(k>kmax)
            kmax=k;
    }
if(c==1)
    fout<<kmax;
else
{
for(i=1;i<=n;i++)
{
   for(j=1;j<=m;j++)
        if(a[i][j]==1)
   {
       nr=0;kf++;
       lee(a,n,m,i,j,nr);
       if(nr>fmax)
        fmax=nr;
   }
}
  fout<<kf<<' '<<fmax;
}
    return 0;
}
