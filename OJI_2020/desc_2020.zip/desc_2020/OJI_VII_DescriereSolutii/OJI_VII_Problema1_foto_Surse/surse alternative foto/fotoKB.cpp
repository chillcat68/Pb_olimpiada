#include <fstream>
#include <cmath>
#include <limits.h>
#define Ni 105
#define Mi 105
using namespace std;

int main()
{
    ifstream f("foto.in");
    ofstream g("foto.out");
    short c;
    f>>c;
    short N,M,i,j, T[Ni][Mi];
    f>>N;

    f>>M;


    for(i=1; i<=N; i++)
        for(j=1; j<=M; j++)
            f>>T[i][j];

    if(c==1)

    {
        short maxi=0,kez;
        for(i=1; i<=N; i++)
        {
            kez=0;
            for(j=1; j<=M; j++)

            {
                if(T[i][j]==1 && j>1)
                {
                    if (maxi<kez)
                    {
                        maxi=kez;
                    }
                    kez=0;
                }
                else if(T[i][j]==0) kez++;
            }
            if(T[i][M]==0)
            {
                if (maxi<kez)
                {
                    maxi=kez;
                }
                kez=0;
            }
        }
        g<<maxi;
    }
    else

    {

        int ta=0,maxk=-1,k=0,l=0;


        for(i=0; i<=N+1; i++)
        {
            T[i][0]=T[i][M+1]=0;
        }
        for(i=0; i<=M+1; i++)
        {
            T[0][i]=T[N+1][i]=0;
        }
        for(i=1; i<=N; i++)
            for(j=1; j<=M; j++)
            {
                if(T[i][j]>=1)
                {

                    k=0;
                    if(T[i-1][j]>=1) k++;
                    if(T[i-1][j-1]>=1) k++;
                    if(T[i-1][j+1]>=1) k++;
                    if(k>1) return 1;
                    l=T[i+1][j]+T[i+1][j-1]+T[i+1][j+1];
                    if(k>1)
                        return 1;
                    if(k==0 && T[i][j]==1)
                        ta++;
                    if(k==1 && T[i][j]>=1)
                    {
                        if(T[i-1][j]>=1) T[i][j]=T[i-1][j]+1;
                        if(T[i-1][j+1]>=1) T[i][j]=T[i-1][j+1]+1;;
                        if(T[i-1][j-1]>=1) T[i][j]=T[i-1][j-1]+1;
                    }

                    if(l==0 && k==0 && T[i][j]==1) if (maxk<0) maxk=1;
                    if(l==0 && k==1)

                        if(maxk<=T[i][j]) maxk=T[i][j];

                }
            }
            
        g<<ta<<" "<<maxk;

    }
    return 0;
}
