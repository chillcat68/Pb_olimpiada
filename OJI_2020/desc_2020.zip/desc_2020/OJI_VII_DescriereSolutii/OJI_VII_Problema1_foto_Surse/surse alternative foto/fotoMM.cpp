#include <fstream>
using namespace std;
ifstream fin("foto.in");
ofstream fout("foto.out");

int imin, imax, a[105][105],n,m,ct;

int platou(int lin)
{
    int l=0,lmax=0,i;
    for(i=1; i<=m; i++)
        if(a[lin][i]==0)
            l++;
        else
        {
            if(l>lmax)
                lmax=l;
            l=0;
        }
    if(l>lmax)
        lmax=l;
    return lmax;
}

void umple(int x,int y, int &xmin, int &xmax)
{
    a[x][y]=0;
    if(x<xmin)
        xmin=x;
    if(x>xmax)
        xmax=x;
    if(y-1>0 && a[x][y-1]==1)
        umple(x,y-1,xmin,xmax);
    if(y-1>0 && x+1<=n && a[x+1][y-1]==1)
        umple(x+1,y-1,xmin,xmax);
    if(x+1<=n && a[x+1][y]==1)
        umple(x+1,y,xmin,xmax);
    if(y+1<=m && x+1<=n && a[x+1][y+1]==1)
        umple(x+1,y+1,xmin,xmax);
    if(y+1<=m && a[x][y+1]==1)
        umple(x,y+1,xmin,xmax);
}

void citire()
{
    int i,j;
    fin>>ct>>n>>m;
    for(i=1; i<=n; i++)
        for(j=1; j<=m; j++)
            fin>>a[i][j];
}

int main()
{
    citire();
    int i, maxi=0,x,j,xmin,xmax,fulgere=0;
    if(ct==1)
    {
        for(i=1; i<=n; i++)
        {
            x=platou(i);
            if(x>maxi)
                maxi=x;
        }
            fout<<maxi<<" ";
        fout<<'\n';
        return 0;
    }
   for(i=1; i<=n; i++)
        for(j=1; j<=m; j++)
            if(a[i][j]==1)
        {
            fulgere++;
            xmin=100;
            xmax=0;
            umple(i,j,xmin,xmax);
            if(xmax-xmin>maxi)
                maxi=xmax-xmin;
        }
     fout<<fulgere<<" "<<maxi+1<<'\n';
     return 0;
}
