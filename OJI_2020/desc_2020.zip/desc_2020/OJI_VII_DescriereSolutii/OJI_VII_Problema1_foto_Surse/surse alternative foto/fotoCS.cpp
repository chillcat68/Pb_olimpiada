#include <fstream>
using namespace std;
ifstream fin("foto.in");
ofstream fout("foto.out");
int a[105][105],n,m,c,i,j;

int fulger(int i, int j)
{ int k=i;
  for(;i<n;i++)
 { a[i][j]=2;
   if(a[i+1][j]==1) continue;
   if(a[i+1][j-1]==1) j--;
   else if(a[i+1][j+1]==1) j++;
        else break;
 }
 if(i==n)a[i][j]=2;
 return i-k+1;
}

void c1()
{int zmax=0, z=0, i, j;
 for(i=1;i<=n;i++)
   { z=0;
     for(j=1;j<=m;j++) if(a[i][j]==0)z++;
                       else {zmax=max(zmax,z);z=0;}
     zmax=max(zmax,z);
   }
   fout<<zmax<<'\n';
}
void c2()
{ int i,j, h, hmax=0, f=0;
      for(i=1;i<=n;i++)
    for(j=1;j<=m;j++)
      if(a[i][j]==1){f++; h=fulger(i,j);
                     hmax=max(hmax,h);
                    }
 fout<<f<<' '<<hmax<<'\n';
}

int main()
{fin>>c>>n>>m;
 for(i=1;i<=n;i++)
    for(j=1;j<=m;j++) fin>>a[i][j];

 if(c==1) c1();
 else c2();
 fin.close();fout.close();
    return 0;
}
