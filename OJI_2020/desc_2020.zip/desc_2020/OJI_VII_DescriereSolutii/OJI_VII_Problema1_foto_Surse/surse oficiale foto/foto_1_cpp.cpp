#include <fstream>
#include <iostream>
using namespace std;
ifstream f("foto.in");
ofstream g("foto.out");
int T[102][102];
int main()
{
    int C,N,M;
    f>>C>>N>>M;

    if(C==1)
    {
        int x,P=0,i,j,p=0;
        for(i=1;i<=N;i++)
        { p=0;
          for(j=1;j<=M;j++)
          { f>>x;
            if(x==0)p++;
            else
              {P=max(p,P); p=0;}
          }
          P=max(P,p);
        }
        g<<P<<endl;
    }
    else
    {
      int H=0,F=0,i,j,h,r,c;
      for(r=1;r<=N;r++)
         for(c=1;c<=M;c++)
            f>>T[r][c];
      for(r=1; r<=N; r++)
       for(c=1; c<=M; c++)
          if(T[r][c]==1)
            { F++;
              i=r; j=c; h=0;
              while(T[i][j]==1)
               {   h++;
                   T[i][j]=0;
                   if(T[i+1][j]==1)i++;
                   else
                   if(T[i+1][j-1]==1){i++;j--;}
                   else
                   if(T[i+1][j+1]==1){i++; j++;}
               }
              H=max(h,H);
            }
     g<<F<<" "<<H<<endl;
    }
    return 0;
}

