#include <fstream>
#include <iostream>
using namespace std;
ifstream f("foto.in");
ofstream g("foto.out");
int T[103][103];

int main()
{
    int C,N,M;
    f>>C>>N>>M;

    if(C==1)
    {
        int x,P=0,i,j,p=0;
        for(i=1;i<=N;i++)
        { p=0;
          for(j=1;j<=M;j++)
          { f>>x;
            if(x==0)p++;
            else
              {P=max(p,P); p=0;}
          }
          P=max(P,p);
        }
        g<<P<<endl;
    }
    else
    {
      int H=0,F=0,i,j,hant;
      for(i=1;i<=N;i++)
         for(j=1;j<=M;j++)
            { f>>T[i][j];
              if(T[i][j]==1)
              {  hant=T[i-1][j-1]+T[i-1][j]+T[i-1][j+1];///lg fulger pana in aceasta pozitie
                 /// doar una dintre valorile T[i-1][j-1],T[i-1][j],T[i-1][j+1]este nenula
                 if (hant==0) F++; ///primul patrat alb din fulger
                 T[i][j]=1+hant;
                 H=max(T[i][j],H);
              }
            }
      g<<F<<" "<<H<<endl;
    }
    return 0;
}

