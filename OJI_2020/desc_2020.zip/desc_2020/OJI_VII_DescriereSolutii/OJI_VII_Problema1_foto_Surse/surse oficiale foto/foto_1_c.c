#include <stdio.h>
int a[102][102];
FILE *f,*g;
int main()
{
    int C,N,M;
    f=fopen("foto.in","r");
    g=fopen("foto.out","w");
    fscanf(f,"%d%d%d",&C,&N,&M);
    if(C==1)
    {
        int x,P=0,i,j,p=0;
        for(i=1;i<=N;i++)
        { p=0;
          for(j=1;j<=M;j++)
          { fscanf(f,"%d",&x);
            if(x==0)p++;
            else
              {if(P<p)P=p;
               p=0;}
          }
          if(P<p)P=p;
        }
        fprintf(g,"%d\n",P);
    }
    else
    {
      int H=0,F=0,i,j,h,r,c;
      for(r=1;r<=N;r++)
         for(c=1;c<=M;c++)
           fscanf(f,"%d",&a[r][c]);
      for(r=1; r<=N; r++)
       for(c=1; c<=M; c++)
          if(a[r][c]==1)
            { F++;
              i=r; j=c; h=0;
              while(a[i][j]==1)
               {   h++;
                   a[i][j]=0;
                   if(a[i+1][j]==1)i++;
                      else
                      if(a[i+1][j-1]==1){i++;j--;}
                      else
                         if(a[i+1][j+1]==1){i++; j++;}
               }
              if(H<h) H=h;
            }
     fprintf(g,"%d %d\n",F,H);
    }
    return 0;
}

