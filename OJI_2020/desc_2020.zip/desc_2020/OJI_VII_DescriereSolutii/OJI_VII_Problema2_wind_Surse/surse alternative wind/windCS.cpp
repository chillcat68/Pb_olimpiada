#include <fstream>
using namespace std;
ifstream fin("wind.in");
ofstream fout("wind.out");
int c, n, i, j, k, dm, um, d, u, emax, emin;
long long e[100005],dif, difm;

void c1(){
 int nrd=-1,d;
 for(d=1;d*d<n;d++)if(n%d==0)nrd+=2;
 fout<< nrd+(d*d==n);
}

long long diferenta(int d, int &u)
{ long long smin,smax,s;
  smin=smax=e[d];u=1;
  for(int i=2*d;i<=n;i+=d)
     { s=e[i]-e[i-d];
       if(s>=smax)smax=s,u=i-d+1;
       else if(s<smin)smin=s;
     }
  return smax-smin;
}

void refresh(int d)
{ dif=diferenta(d,u);
  if(dif<difm || dif==difm && d<dm)difm=dif,dm=d,um=u;
}
void c2(){
  dm=1;um=1;
  fin>>e[1];emax=emin=e[1];
  for(i=2;i<=n;i++){fin>>e[i];
                    if(e[i]<emin)emin=e[i];
                    else if(e[i]>=emax) emax=e[i],um=i;
                    e[i]+=e[i-1];}

  difm=emax-emin;
  for(d=2;d*d<n;d++)
   if(n%d==0){ refresh(d);refresh(n/d);}
  if(d*d==n)refresh(d);
   fout<<n/dm<<' '<<um;
}
int main()
{ fin>>c>>n;
  if(c==1)c1();
  else c2();
  fin.close();fout.close();
    return 0;
}
