///#include <iostream>
#include <fstream>
using namespace std;
ifstream f("wind.in");
ofstream g("wind.out");
long long s[100001];
int N,cer;
int nr_divizori()
{   if(N==1)return 1;
    int k=2,d;
    for(d=2;d*d<=N;d++)
    {
        if(N%d==0)
        {   k++;
            if(d*d!=N)k++;
        }
    }
    return k;
}

int main()
{
  f>>cer>>N;
  if(cer==1)
    {g<<nr_divizori()-1; return 0;}
  ///cerinta 2
  int ind=1,d,k,indk,nro=N,i,j,tt=2;
  long long x, dmin, sd,sdmin,sdmax,difkmin, xmin, xmax;
  f>>s[1];
  xmin=xmax=s[1];
  for(i=2;i<=N;i++)
  {
      f>>x;
      xmin=min(xmin,x);
      if(x>=xmax){xmax=x; ind=i;}
      s[i]=s[i-1]+x;
  }
  dmin=xmax-xmin;
  s[0]=0;
  for(d=2;d<=N/2;d++)
  {
    if(N%d==0)
    { k=N/d; sdmin=sdmax=s[d];indk=1;

      for(j=d;j<=N;j=j+d)
      { sd=(s[j]-s[j-d]);
        if(sd<sdmin)sdmin=sd;
        if(sd>=sdmax)
        {  sdmax=sd; indk=j-d+1; }
      }
      difkmin=sdmax-sdmin;

      if(difkmin<dmin)
      { nro=k; dmin=difkmin;ind=indk; tt=d; }
      else if(difkmin==dmin && nro<k)
           { nro=k; ind=indk; }
    }
  }
  g<<nro<<" "<<ind;
  return 0;
}
